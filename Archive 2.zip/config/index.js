const { PrismaClient } = require('@prisma/client');
const nodemailer = require('nodemailer');

const service = process.env.EMAIL.includes('outlook') ? {
  service: 'hotmail'
} : {
  host: 'smtp.gmail.com',
  port: 465,
  secure: true,
}
const transport = nodemailer.createTransport({
  ...service,
  auth: {
    user: process.env.EMAIL,
    pass: process.env.PASS,
  },
});

const prisma = new PrismaClient();

const cloudinary = require('cloudinary').v2;
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});
const Amplitude = require('@amplitude/node');
const client = Amplitude.init(process.env.AMPLITUDE_KEY);

module.exports = {
  prisma,
  env: process.env,
  cloudinary,
  amplitudeClient: client,
  transport,
};
