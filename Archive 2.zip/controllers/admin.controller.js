const { prisma } = require('../config');
require('dotenv').config();
const { sign } = require('jsonwebtoken');
const thisYear = new Date().getFullYear();
const reduceToDays = t => {
    t.createdDate = (new Date(t.createdDate).getTime() - new Date("1/1/" + thisYear).getTime()) / (1000 * 60 * 60 * 24)
    return t
}
const filterThisYear = x => new Date(x.createdDate).getFullYear() === thisYear
const sortDate = (x, y) => x.createdDate - y.createdDate
const transformDates = (t) => t
    .filter(x => new Date(x.createdDate).getFullYear() === thisYear)
    .map(reduceToDays)
    .sort(sortDate)
const months = ['JA', 'FE', 'MR', 'AP', 'MY', 'JN', 'JL', 'AU', 'SE', 'OC', 'NV', 'DE', 'EX']

class AdminClass {
    async loginAdmin(req, res, next) {
        const { username, password } = req.body
        if (username === process.env.ADMIN_USERNAME && password === process.env.ADMIN_PASSWORD) {

            const admin = await prisma.user.upsert({
                where: {
                    phoneNumber: '0000000000',
                },
                update: {},
                create: {
                    fullName: username,
                    phoneNumber: '0000000000',
                    isAdmin: true,
                    isOrganizer: true
                },
            })
            const accessToken = sign(
                {
                    id: admin.id
                },
                process.env.ACCESS_KEY,
            );
            return res.json({
                success: true,
                accessToken
            });
        }
        return res.json({
            success: false,
            message: "Failed to authenticate admin"
        })
    }
    async dashboard(req, res, next) {
        const users = await prisma.user.aggregate({
            _count: {
                id: true
            }
        });
        const organizers = await prisma.user.aggregate({
            _count: {
                id: true
            },
            where: {
                isOrganizer: true
            }
        });
        const admins = await prisma.user.aggregate({
            _count: {
                id: true
            },
            where: {
                isAdmin: true
            }
        });
        const trips = await prisma.trip.aggregate({
            _count: {
                id: true
            }
        });
        const paidTransactions = await prisma.tnx.aggregate({
            _count: {
                id: true
            },
            where: {
                isPaid: true
            }
        });
        const unpaidTransactions = await prisma.tnx.aggregate({
            _count: {
                id: true
            },
            where: {
                isPaid: false
            }
        });
        const categories = await prisma.category.aggregate({
            _count: {
                id: true
            }
        });
        const destinations = await prisma.trip.aggregate({
            _count: {
                destinationId: true
            }
        });
        const packageIncludes = await prisma.tripPackageIncluded.aggregate({
            _count: {
                id: true
            }
        });
        const activities = await prisma.tripActivities.aggregate({
            _count: {
                id: true
            }
        });
        const moneyGenerated = await prisma.tnx.aggregate({
            _sum: {
                amount: true
            }
        });
        const counts = [];
        counts.push({ title: 'Users', count: users._count.id });
        counts.push({ title: 'Organizers', count: organizers._count.id });
        counts.push({ title: 'Admins', count: admins._count.id });
        counts.push({ title: 'Trips', count: trips._count.id });
        counts.push({ title: 'Paid bookings', count: paidTransactions._count.id });
        counts.push({ title: 'Unpaid bookings', count: unpaidTransactions._count.id });
        counts.push({ title: 'Packages Included', count: packageIncludes._count.id });
        counts.push({ title: 'Activities', count: activities._count.id });
        counts.push({ title: 'Destinations', count: destinations._count.destination });
        counts.push({ title: 'Categories', count: categories._count.id });
        counts.push({ title: 'Birr generated', count: moneyGenerated._sum.amount });


        const bookingHistory = await new AdminClass().getTransactionHistory()
        const destinationDistribution = await new AdminClass().getDestinationDistribution()
        const usersHistory = await new AdminClass().getUsersHistory()
        const moneyHistory = await new AdminClass().getMoneyHistory()
        const categoryPie = await new AdminClass().getCategoryPie()

        return res.json({
            counts,
            history: {
                bookingHistory,
                destinationDistribution,
                usersHistory,
                moneyHistory
            },
            pie: {
                booking: [
                    { status: "paid", count: paidTransactions._count.id },
                    { status: "unpaid", count: unpaidTransactions._count.id }
                ],
                categories: categoryPie
            }
        });
    }
    async getTransactionHistory() {
        let transactions = transformDates(await prisma.tnx.findMany());
        const result = Array(52).fill()
            .map((_, i) => ({
                paid: 0,
                unpaid: 0,
                week: months[Math.floor(i / 4.34524)] + (Math.floor(i % 4.34524) + 1)
            }))
        const visited = new Set();
        if (transactions.length) {
            for (let i = 0; i < 52; i++) {
                transactions.forEach(t => {
                    if (!visited.has(t.id))
                        if (t.createdDate < (i + 1) * 7.02) {
                            if (t.isPaid) {
                                result[i].paid += 1
                                // result[i].paid += 1
                            } else {
                                result[i].unpaid += 1
                                // result[i].unpaid += 1
                            }
                            visited.add(t.id)
                        }
                })
            }

        }
        return result;
    }
    async getUsersHistory() {
        let users = transformDates(await prisma.user.findMany());
        const result = Array(52).fill()
            .map((_, i) => ({
                count:0,
                week: months[Math.floor(i / 4.34524)] + (Math.floor(i % 4.34524) + 1)
            }))
        const visited = new Set();
        if (users.length) {
            for (let i = 0; i < 52; i++) {
                users.forEach(t => {
                    if (!visited.has(t.id))
                        if (t.createdDate < (i + 1) * 7.02) {
                            result[i].count += 1
                            visited.add(t.id)
                        }
                })
            }

        }
        return result;
    }
    async getMoneyHistory() {
        let tnx = transformDates(await prisma.tnx.findMany());
        const result = Array(52).fill()
            .map((_, i) => ({
                count: 0,
                week: months[Math.floor(i / 4.34524)] + (Math.floor(i % 4.34524) + 1)
            }))
        const visited = new Set();
        if (tnx.length) {
            for (let i = 0; i < 52; i++) {
                tnx.forEach(t => {
                    if (!visited.has(t.id))
                        if (t.createdDate < (i + 1) * 7.02) {
                            result[i].count += t.amount
                            visited.add(t.id)
                        }
                })
            }

        }
        return result;
    }
    async getDestinationDistribution() {
        const trips = (await prisma.trip.groupBy({
            by: ['destinationId'],
            _count: {
                categoryId: true,
                communityId: true,
                isChildFriendly: true,
            },
        })).map(t => {
            return {
                communities: t._count.communityId,
                categories: t._count.categoryId,
                isChildFriendly: t._count.isChildFriendly,
                destination: t.destination
            }
        })

        return trips
    }
    async getCategoryPie() {
        const tripCount = (await prisma.trip.groupBy({
            by: ['categoryId'],
            _count: {
                id: true,
            },
        }))
        const result = []
        for (const t of tripCount) {
            result.push({
                count: t._count.id,
                category: (await prisma.category.findFirst({
                    where: { id: t.categoryId }
                }))?.name
            })
        }
        return result
    }
}

module.exports = new AdminClass();