const { default: Chapa } = require('chapa-node');
const { error: serverError } = require('../utils');
const crypto = require('crypto');
const { prisma, transport } = require('../config');
const { sendSms } = require('../utils/sms');
require('dotenv').config();

const chapaKey = process.env.CHAPA_KEY;
const apiUrl =
  process.env.NODE_ENV === 'development'
    ? process.env.APP_DOMAIN_DEV
    : process.env.APP_DOMAIN_PROD;
const webUrl =
  process.env.NODE_ENV === 'development'
    ? process.env.APP_DOMAIN_WEB_DEV
    : process.env.APP_DOMAIN_WEB_PROD;
const chapaWebHookHash = process.env.CHAPA_WEBHOOK_HASH;

const chapa = new Chapa(chapaKey);

class ChapaController {
  /**
   *
   * @param {import('express').Request} req
   * @param {import('express').Response} res
   * @param {import('express').NextFunction} next
   *
   */
  async initializePayment(req, res, next) {
    try {
      const tripId = req.params.id;
      const user = res.locals.user;
      console.log(user);
      const { emergencyNumber, amountOfPeople } = req.body;
      await prisma.user.update({
        where: {
          id: user.id
        },
        data: {
          emergencyNumber
        }
      })
      const trip = await prisma.trip.findUnique({
        where: { id: tripId },
        include: {
          organizerCommunity: true,
        },
      });
      if (!trip) {
        throw new Error('Trip not found');
      }
      let amount = trip.price * amountOfPeople;
      if (trip.discounted) {
        amount = amount - (trip.discountAmount * amountOfPeople);
      }

      const tx_ref = chapa.generateTxRef();
      const sf = user.fullName.split(' ')
      const firstName = sf[0]
      let lastName = 'X';
      if (sf.length > 1) {
        lastName = sf.slice(1).join(' ')
      }
      const response = await chapa.initialize({
        first_name: firstName,
        last_name: lastName,
        email: '',
        amount,
        tx_ref,
        phone_number: user.phoneNumber,
        currency: 'ETB',
        return_url: `${webUrl}/thankyou?receipt=${tx_ref}`,
        callback_url: `${apiUrl}/api/chapa/update/${tx_ref}`,
        subaccounts: [ 
          {
            id: trip.organizerCommunity.subAccountId,
            split_type: 'percentage',
            split_value: 0,
          },
        ],
      });

      if (response.status === 'success') {
        const tnxOld = await prisma.tnx.findFirst({
          where: {
            userId: user.id,
            tripId,
            isPaid: false,
          },
        });
        if (tnxOld.isPaid) {
          serverError('Payment', "You've already paid for this trip!", res, 500);
        }
        if (tnxOld) {
          await prisma.tnx.update({
            where: { tnxRef: tnxOld.tnxRef },
            data: {
              tripId,
              tnxRef: tx_ref,
              userId: user.id,
              amount,
              paymentMethod: 'chapa',
              initiatedPayment: true,
              amountOfPeople
            },
          });
        } else {
          await prisma.tnx.create({
            data: {
              tripId,
              tnxRef: tx_ref,
              userId: user.id,
              amount,
              paymentMethod: 'chapa',
              initiatedPayment: true,
              amountOfPeople
            },
          });
        }

        res.redirect(response.data.checkout_url)
      }
    } catch (error) {
      serverError('server', error, res, 500);
    }
  }
  async initializePayLater(req, res, next) {
    const tripId = req.params.id;
    const user = res.locals.user;
    let { emergencyNumber, amountOfPeople } = req.body;
    amountOfPeople = Number(amountOfPeople)
    if (emergencyNumber) {
      await prisma.user.update({
        where: {
          userId: user.id
        },
        date: {
          emergencyNumber
        }
      })
    }
    const t = await prisma.tnx.findFirst({
      where: {
        tripId,
        userId: user.id
      },
    })
    if (t) {
      await prisma.tnx.update({
        where: {
          id: t.id
        },
        data: {
          amountOfPeople

        }
      })
    } else {
      await prisma.tnx.create({
        data: {
          tripId,
          userId: user.id,
          amountOfPeople
        }
      })
    }

    return res.redirect(`${webUrl}/thankyou`)
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import('express').Response} res
   * @param {import("express").NextFunction} next
   *
   */
  async update(req, res, next) {
    try {
      const tnxRef = req.params.tnxRef;
      const response = await chapa.verify(tnxRef);

      if (response.status === 'success') {
        const tnx = await prisma.tnx.update({
          where: {
            tnxRef: tnxRef,
          },
          data: {
            isPaid: true,
          },
          include: {
            trip: true,
            user: true
          }
        });
        const trip = await prisma.trip.findUnique({
          where: { id: tnx.tripId }
        });
        if (!trip) {
          throw new Error('tripId', 'no trip found with this id', res, 404);
        }
        const organizerCommunity = await prisma.community.findUnique({
          where: { id: trip.communityId },
          include: {
            organizer: true
          }
        });
        if (!organizerCommunity.organizer) {
          throw new Error('tripId', 'trip organizer not found', res, 404);
        }
        const message = {
          from: process.env.EMAIL,
          to: `<kenenisaalemayhu0@gmail.com>`,
          subject: 'Your trip has been booked ✔',
          html: `<p>Hello ${organizerCommunity.organizer.fullName}<br/>
                Your trip <a href="${webUrl}/trip/${tnx.tripId}">${trip.name}</a> is booked by.<br/>
                firstName: ${tnx.user.fullName}<br/> 
                PhoneNumber: ${tnx.user.phoneNumber}<br/>
                </p>`,
        };

        await transport.sendMail(message);
        // await sendSms(tnx.user.phoneNumber,)
        res.sendStatus(200);
      }
    } catch (error) {
      console.dir(error, { depth: Infinity });
      serverError('server', error, res, 500);
    }
  }

  /**
   *
   * @param {import('express').Request} req
   * @param {import('express').Response} res
   * @param {import('express').NextFunction} next
   */
  async webHook(req, res, next) {
    try {
      const utenticHash = crypto
        .createHmac('sha256', chapaWebHookHash)
        .update(JSON.stringify(req.body))
        .digest('hex');
      const chapaHash = req.headers['x-chapa-signature'];
      const { status, tx_ref } = req.body;

      if (utenticHash === chapaHash && status === 'success') {
        const tnx = await prisma.tnx.update({
          where: {
            tnxRef: tx_ref,
          },
          data: {
            isPaid: true,
          },
        });

        const trip = await prisma.trip.findUnique({
          where: { id: tnx.tripId },
          include: {
            community: {
              include: {
                user: true
              }
            }
          }
        });
        if (!trip) {
          throw new Error('tripId', 'no trip found with this id', res, 404);
        }
        // const organizer = await prisma.user.findUnique({
        //   where: { id: trip.organizerUserId },
        // });

        // if (!organizer) {
        //   throw new Error('tripId', 'trip organizer not found', res, 404);
        // }
        // const message = {
        //   from: process.env.EMAIL,
        //   to: `<dev.utentic@gmail.com>`,
        //   subject: 'Your trip has been booked ✔',
        //   html: `<p>Hello ${organizer.firstName}<br/>
        //         Your trip <a href="${process.env.APP_DOMAIN_WEB}/trip/${tnx.tripId}">${trip.name}</a> is booked by.<br/>
        //         firstName: ${tnx.firstName}<br/> 
        //         PhoneNumber: ${tnx.phoneNumber}<br/>
        //         </p>`,
        // };

        // await transport.sendMail(message);
        res.sendStatus(200);
      }
    } catch (error) {
      serverError('server', error, res, 500);
    }
  }

  /**
   *
   * @param {import('express').Request} req
   * @param {import('express').Response} res
   * @param {import('express').NextFunction} next
   */
  async verify(req, res, next) {
    try {
      const tnxRef = req.params.tnxRef;
      const tnx = await prisma.tnx.findUnique({
        where: {
          tnxRef: tnxRef,
        },
        include: {
          trip: true,
        },
      });
      if (!tnx) return serverError('TxRef', 'This Transaction is not found', next, 400);

      if (tnx) {
        const { name, destination, meetUpLocation, price } = tnx.trip;
        const { firstName } = tnx;
        res.send({
          success: true,
          data: { name, destination, meetUpLocation, price, firstName },
        });
      }
    } catch (error) {
      serverError('server', error, res, 500);
    }
  }

  async bankCodes(req, res) {
    const allBanks = await chapa.getBanks();
    return res.json({
      success: Boolean(allBanks),
      data: allBanks
    })
  }
}

module.exports = new ChapaController();
