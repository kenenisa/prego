const { prisma } = require('../config');
const { error } = require('../utils');
class DestinationsController {
    /**
     *
     * @param {import("express").Request} req
     * @param {import("express").Response} res
     * @param {import("express").NextFunction} next
     * @returns
     */
    async newDestinations(req, res, next) {
        const { name } = req.body;
        if (!name) {
            return error('name', 'destinations name is required', res);
        }
        try {
            const created = await prisma.destination.create({
                data: {
                    name,
                },
            });
            return res.json({
                success: true,
                data: created,
            });
        } catch (e) {
            console.log(e);
            return error(
                'server',
                'internal server error when trying to create destinations',
                next,
            );
        }
    }
    /**
     *
     * @param {import("express").Request} req
     * @param {import("express").Response} res
     * @param {import("express").NextFunction} next
     * @returns
     */
    async getDestinations(req, res, next) {
        const { limit, skip } = req.query;
        let filterLimit = Number(limit) || undefined;
        let filterSkip = Number(skip) || undefined;
        try {
            return res.json({
                success: true,
                meta: {
                    total: await prisma.destination.count(),
                },
                data: await prisma.destination.findMany({
                    take: filterLimit,
                    skip: filterSkip,
                    include: {
                        _count: true,
                    }
                }),
            });
        } catch (e) {
            console.log(e);
            return error(
                'server',
                'internal server error when trying to get destinations',
                res,
            );
        }
    }
    /**
     *
     * @param {import("express").Request} req
     * @param {import("express").Response} res
     * @param {import("express").NextFunction} next
     * @returns
     */
    async updateDestinations(req, res, next) {
        if (!req.body.updateData) {
            return error('updateData', 'please send updateData', res);
        }
        const { name } = req.body.updateData;
        try {
            if (!req.params.destinationsId) {
                return error('destinationsId', 'please send destination Id', res, 404);
            }
            const destinations = await prisma.destination.findUnique({
                where: { id: req.params.destinationsId },
            });
            if (!destinations) {
                return error('destinationsId', 'no destination exists with this id', res, 404);
            }
            const updated = await prisma.destination.update({
                where: { id: destinations.id },
                data: { name },
            });
            return res.json({
                success: true,
                data: updated,
            });
        } catch (e) {
            console.log(e);
            return error(
                'server',
                'internal server error when trying to update destinations',
                next,
            );
        }
    }
    /**
     *
     * @param {import("express").Request} req
     * @param {import("express").Response} res
     * @param {import("express").NextFunction} next
     * @returns
     */
    async deleteDestinations(req, res, next) {
        try {
            if (!req.params.destinationsId) {
                return error('destination', 'please send destinations Id', res, 404);
            }
            const destinations = await prisma.destination.findUnique({
                where: { id: req.params.destinationsId },
            });
            if (!destinations) {
                return error('destinationsId', 'no destinations exists with this id', res, 404);
            }

            const deleted = await prisma.destination.delete({
                where: { id: destinations.id },
            });
            return res.json({
                success: true,
                data: deleted,
            });
        } catch (e) {
            console.log(e);
            return error(
                'server',
                'internal server error when trying to delete category',
                next,
            );
        }
    }
}
module.exports = new DestinationsController();
