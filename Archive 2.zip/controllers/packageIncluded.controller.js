const { prisma } = require('../config');
const { error } = require('../utils');
class PackageIncludedController {
    /**
     *
     * @param {import("express").Request} req
     * @param {import("express").Response} res
     * @param {import("express").NextFunction} next
     * @returns
     */
    async newPackageIncluded(req, res, next) {
        const { name } = req.body;
        if (!name) {
            return error('name', 'Package name is required', res);
        }
        try {
            const created = await prisma.tripPackageIncluded.create({
                data: {
                    name,
                },
            });
            return res.json({
                success: true,
                data: created,
            });
        } catch (e) {
            console.log(e);
            return error(
                'server',
                'internal server error when trying to create package',
                next,
            );
        }
    }
    /**
     *
     * @param {import("express").Request} req
     * @param {import("express").Response} res
     * @param {import("express").NextFunction} next
     * @returns
     */
    async getPackageIncluded(req, res, next) {
        const { limit, skip } = req.query;
        let filterLimit = Number(limit) || undefined;
        let filterSkip = Number(skip) || undefined;
        try {
            return res.json({
                success: true,
                meta: {
                    total: await prisma.tripPackageIncluded.count(),
                },
                data: await prisma.tripPackageIncluded.findMany({
                    take: filterLimit,
                    skip: filterSkip,
                    include: {
                        _count: true,
                    }
                }),
            });
        } catch (e) {
            console.log(e);
            return error(
                'server',
                'internal server error when trying to create category',
                next,
            );
        }
    }
    /**
     *
     * @param {import("express").Request} req
     * @param {import("express").Response} res
     * @param {import("express").NextFunction} next
     * @returns
     */
    async updatePackageIncluded(req, res, next) {
        if (!req.body.updateData) {
            return error('updateData', 'please send updateData', res);
        }
        const { name } = req.body.updateData;
        try {
            if (!req.params.packageIncludedId) {
                return error('packageIncludedId', 'please send packageIncluded Id', res, 404);
            }
            const packageIncluded = await prisma.tripPackageIncluded.findUnique({
                where: { id: req.params.packageIncludedId },
            });
            if (!packageIncluded) {
                return error('packageIncludedId', 'no package exists with this id', res, 404);
            }
            const updated = await prisma.tripPackageIncluded.update({
                where: { id: packageIncluded.id },
                data: { name },
            });
            return res.json({
                success: true,
                data: updated,
            });
        } catch (e) {
            console.log(e);
            return error(
                'server',
                'internal server error when trying to update package',
                next,
            );
        }
    }
    /**
     *
     * @param {import("express").Request} req
     * @param {import("express").Response} res
     * @param {import("express").NextFunction} next
     * @returns
     */
    async deletePackageIncluded(req, res, next) {
        try {
            if (!req.params.packageIncludedId) {
                return error('packageIncluded', 'please send packageIncluded Id', res, 404);
            }
            const packageIncluded = await prisma.tripPackageIncluded.findUnique({
                where: { id: req.params.packageIncludedId },
            });
            if (!packageIncluded) {
                return error('categoryId', 'no category exists with this id', res, 404);
            }
            // if (category.trip.length) {
            //   return error(
            //     'trip',
            //     "can't delete a category if it has trips registered under it",
            //     next,
            //   );
            // }
            const deleted = await prisma.tripPackageIncluded.delete({
                where: { id: packageIncluded.id },
            });
            return res.json({
                success: true,
                data: deleted,
            });
        } catch (e) {
            console.log(e);
            return error(
                'server',
                'internal server error when trying to delete category',
                next,
            );
        }
    }
}
module.exports = new PackageIncludedController();
