const { default: Chapa } = require('chapa-node');
const { sign } = require('jsonwebtoken');
const { prisma, transport } = require('../config');
const { VALIDATION_TYPE } = require('../config/constants');
const { getOneUser, updateUser } = require('../services/user.services');
const { error } = require('../utils');
const { uploadFile } = require('../utils/upload');
const { allValidations } = require('../utils/validation');
require('dotenv').config();
const { sendSms } = require('../utils/sms');

class UserController {
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async login(req, res, next) {
    try {
      if (!req.body.phoneNumber) {
        return error('phoneNumber', 'please send phone number', res);
      }

      const [{ success, message, argument, value }] = allValidations([
        {
          type: VALIDATION_TYPE.PHONE_NUMBER,
          value: req.body.phoneNumber,
          argument: 'phoneNumber',
        },
      ]);
      
      const phoneNumber = value;
      console.log({ phoneNumber });
      if (!success) return error(argument, message, res);
      const userExists = await prisma.user.findFirst({
        where: { phoneNumber },
      });
      if (!userExists) return error('phoneNumber', 'user not found', res, 404);

      const sms = await sendSms(userExists.phoneNumber);
      if (!sms.success) {
        return error('server', 'sms service failed', res, 500);
      }

      await prisma.user.update({
        where: { phoneNumber },
        data: {
          otp: sms.otp,
        },
      });
      res.status(200).json({
        message: 'User signed in successfully please check your phone for otp',
        user: userExists,
      });

      return;
    } catch (e) {
      console.log(e);
      return error('server', 'sign in failed please try again', res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async auth(req, res, next) {
    try {
      if (!req.body.phoneNumber) {
        return error('phoneNumber', 'please send phone number', res);
      }
      if (!req.body.fullName) {
        return error('fullName', 'please send fullName', res);
      }
      const [{ success, message, argument, value }] = allValidations([
        {
          type: VALIDATION_TYPE.PHONE_NUMBER,
          value: req.body.phoneNumber,
          argument: 'phoneNumber',
        },
      ]);
      const phoneNumber = value;
      if (!success) return error(argument, message, res);
      const { fullName } = req.body;
      const user = await prisma.user.upsert({
        where: { phoneNumber },
        update: {},
        create: {
          phoneNumber,
          fullName,
        },
      });
      const sms = await sendSms(user.phoneNumber);
      if (!sms.success) {
        return error('server', 'sms service filed please try again', res, 500);
      }
      await prisma.user.update({
        where: { phoneNumber: user.phoneNumber },
        data: {
          otp: sms.otp,
        },
      });

      return res.status(201).json({
        user,
        message: 'User signed up successfully please check your phone for otp',
      });
    } catch (e) {
      console.log(e);
      return error('server', 'sign up failed please try again', res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async verifyOTP(req, res, next) {
    try {
      const { otp, phoneNumber } = req.body;
      if (!otp) return error('otp', 'please send otp', res);
      const user = await prisma.user.findUnique({
        where: {
          phoneNumber
        },
      });

      if (!user) return error('user', 'phone number doesnt exist', res);
      if (!user.otp) return error('otp', 'Wrong OTP code', res);
      const accessToken = sign(
        {
          id: user.id,
        },
        process.env.ACCESS_KEY,
      );
      await prisma.user.update({
        where: {
          phoneNumber
        },
        data: {
          otp: null
        }
      });

      return res.json({
        success: true,
        data: {
          accessToken,
          user,
        },
      });
    } catch (e) {
      console.log(e);
      return error('server', 'sign up failed please try again', res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async resendOTP(req, res, next) {
    try {
      const { phoneNumber } = req.body;
      if (!phoneNumber) {
        return error('phoneNumber', 'Please send phoneNumber.', res);
      }
      const existUser = await prisma.user.findUnique({
        where: {
          phoneNumber,
        },
      });
      if (!existUser) return error('server', 'Use not found.', res, 404);
      const oldOTP = await prisma.otp.findFirst({
        where: {
          phoneNumber,
          userId: existUser.id,
        },
      });
      if (oldOTP) {
        await prisma.otp.delete({
          where: {
            id: oldOTP.id,
          },
        });
      }

      const sms = await sendSms(phoneNumber);
      if (!sms.success) {
        return error('server', 'sms service failed', res, 500);
      }

      await prisma.otp.create({
        data: {
          otp: sms.otp,
          phoneNumber,
          userId: existUser.id,
        },
      });

      res.status(200).json({
        message: 'New OPT send to user phoneNumber',
      });

      return;
    } catch (e) {
      console.log(e);
      return error('server', 'Resending OTP failed', res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async updateSelf(req, res, next) {
    if (!req.body.updateData) {
      return error('updateData', 'please send updateData', res);
    }
    const returnVal = await updateUser(res.locals.id, req.body.updateData, res);
    if (returnVal) {
      return res.json(returnVal);
    } else {
      return returnVal;
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async updateProfile(req, res, next) {
    try {
      const profile = await uploadFile(req.file.path, 'USER', res.locals.id, false);
      const updatedUser = await prisma.user.update({
        where: { id: res.locals.id },
        data: { profile },
      });
      return res.json({ success: true, data: updatedUser });
    } catch (e) {
      console.log(e);
      return error('server', 'upload failed please try again', res, 500);
    }
  }
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async updateBanner(req, res, next) {
    try {
      const banner = await uploadFile(req.file.path, 'USER', res.locals.id, true);
      const updatedUser = await prisma.user.update({
        where: { id: res.locals.id },
        data: { banner },
      });
      return res.json({ success: true, data: updatedUser });
    } catch (e) {
      return error('server', 'upload failed please try again', res, 500);
    }
  }
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async getMe(req, res, next) {
    const returnVal = await getOneUser(res.locals.id, res);
    if (returnVal) {
      return res.json(returnVal);
    } else {
      return returnVal;
    }
  }
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async getWithId(req, res, next) {
    const returnVal = await getOneUser(req.params.userId, res);

    if (returnVal) {
      return res.json(returnVal);
    } else {
      return returnVal;
    }
  }
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async getAll(req, res, next) {
    const { communityId, tripId, limit, skip } = req.query;
    let filterLimit = Number(limit) || undefined;
    let filterSkip = Number(skip) || undefined;
    try {
      const users = await prisma.user.findMany({
        where: {
          deletedStatus: false,
          // followedCommunities: communityId
          //   ? {
          //     some: {
          //       id: communityId || undefined,
          //     },
          //   }
          //   : communityId,
          bookedTrips: tripId
            ? {
              some: {
                id: tripId || undefined,
              },
            }
            : undefined,
        },
        take: filterLimit,
        skip: filterSkip,
        include: {
          _count: true,
          communities: {
            include: {
              _count: true,
              organizedTrips: {
                include: {
                  _count: true
                }
              }
            }
          }
          // followedCommunities: { take: 3 },
        },
      });
      const metaCount = await prisma.user.count({
        where: { deletedStatus: false },
      });
      return res.json({
        success: true,
        data: users,
        meta: {
          total: metaCount,
        },
      });
    } catch (e) {
      console.log(e);
      return error(
        'server',
        'something went wrong in retriving the account informations',
        next,
        500,
      );
    }
  }
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async followCommunity(req, res, next) {
    try {
      if (!req.params.communityId) {
        return error('communityId', 'please send community Id', res, 404);
      }
      const community = await prisma.community.findUnique({
        where: { id: req.params.communityId },
      });
      if (!community) {
        return error('communityId', 'no community found with this id', res, 404);
      }
      const updatedUser = await prisma.user.update({
        where: {
          id: res.locals.id,
        },
        data: {
          followedCommunities: {
            connect: {
              id: community.id,
            },
          },
        },
      });
      return res.json({
        success: true,
        data: updatedUser,
      });
    } catch (e) {
      console.log(e);
      return error('server', 'something went wrong', res, 500);
    }
  }
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async unFollowCommunity(req, res, next) {
    try {
      if (!req.params.communityId) {
        return error('communityId', 'please send community Id', res, 404);
      }
      const community = await prisma.community.findUnique({
        where: { id: req.params.communityId },
      });
      if (!community) {
        return error('communityId', 'no community found with this id', res, 404);
      }
      if (community.creatorId === res.locals.id) {
        return error('communityId', "you can't follow your own community", res);
      }
      await prisma.user.update({
        where: {
          id: res.locals.id,
        },
        data: {
          followedCommunities: {
            disconnect: {
              id: community.id,
            },
          },
          managedCommunities: {
            disconnect: {
              id: community.id,
            },
          },
        },
      });
      return res.json({ success: true });
    } catch (e) {
      return error('server', 'something went wrong', res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async bookTrip(req, res, next) {
    try {
      const { fullName, phoneNumber, ticket } = req.body;
      if (!req.params.tripId) {
        return error('tripId', 'please send trip Id', res, 404);
      }
      const trip = await prisma.trip.findUnique({
        where: { id: req.params.tripId },
      });
      if (!trip) {
        return error('tripId', 'no trip found with this id', res, 404);
      }

      const organizer = await prisma.user.findUnique({
        where: { id: trip.organizerId },
      });

      if (!organizer) {
        return error('tripId', 'trip organizer not found', res, 404);
      }

      const tnxRef = new Chapa(process.env.CHAPA_KEY).generateTxRef();
      const tnxOld = await prisma.tnx.findFirst({
        where: {
          fullName,
          tripId: trip.id,
          phoneNumber,
          isPaid: false,
        },
      });
      if (tnxOld) {
        await prisma.tnx.update({
          where: { tnxRef: tnxOld.tnxRef },
          data: {
            tripId: trip.id,
            tnxRef,
            fullName,
            phoneNumber,
            paymentMethod: 'mobile',
          },
        });
      } else {
        await prisma.tnx.create({
          data: {
            tripId: trip.id,
            tnxRef,
            fullName,
            phoneNumber,
          },
        });
      }

      const getAmount = (ticket) =>
        trip?.discounted
          ? trip.price * ticket -
          trip.discountAmount * Math.floor(ticket / trip.discountPeople)
          : trip.price * ticket;

      const totalAmount = getAmount(ticket);

      const message = {
        from: process.env.EMAIL,
        to: `<dev.utentic@gmail.com>`,
        subject: 'Your trip has been booked ✔',
        html: `<p>Hello ${organizer.firstName}<br/>
              Your trip <a href="${process.env.APP_DOMAIN_WEB_PROD}/trip/${trip.id}">${trip.name
          }</a> is booked by.<br/>
              FirstName: ${fullName}<br/> 
              PhoneNumber: ${phoneNumber}<br/> 
              NumberOfTicket: ${ticket}<br/>
              TotalPrice: ${totalAmount}<br/>
              Discount: ${trip.discounted ? trip.discountAmount : 0}<br/>
              </p>`,
      };

      await transport.sendMail(message);
      return res.json({ success: true, data: tnxRef });
    } catch (e) {
      return error('server', 'something went wrong', res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async unBookTrip(req, res, next) {
    try {
      if (!req.params.tripId) {
        return error('tripId', 'please send trip Id', res, 404);
      }
      const trip = await prisma.trip.findUnique({
        where: { id: req.params.tripId },
      });
      if (!trip) {
        return error('tripId', 'no trip found with this id', res, 404);
      }
      await prisma.user.update({
        where: { id: res.locals.id },
        data: { bookedTrips: { disconnect: { id: trip.id } } },
      });
      return res.json({ success: true });
    } catch (e) {
      return error('server', 'something went wrong', res, 500);
    }
  }
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async activateUser(req, res, next) {
    try {
      if (!req.params.userId) {
        return error('userId', 'please send user Id', res, 404);
      }
      const user = await prisma.user.findUnique({
        where: { id: req.params.userId },
      });
      if (!user) {
        return error('user', 'no user found with this id', res, 404);
      }
      await prisma.user.update({
        where: { id: user.id },
        data: { deletedStatus: false },
      });
      return res.json({ success: true });
    } catch (e) {
      return error('server', 'something went wrong', res, 500);
    }
  }
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async deactivateUser(req, res, next) {
    try {
      if (!req.params.userId) {
        return error('userId', 'please send user Id', res, 404);
      }
      const user = await prisma.user.findUnique({
        where: { id: req.params.userId },
      });
      if (!user) {
        return error('user', 'no user found with this id', res, 404);
      }
      // await prisma.user.update({
      //   where: { id: user.id },
      //   data: { deletedStatus: true },
      // });

      await prisma.user.delete({
        where: { id: user.id },
      });
      return res.json({ success: true });
    } catch (e) {
      return error('server', 'something went wrong', res, 500);
    }
  }
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async removeUser(req, res, next) {
    try {
      if (!req.params.userId) {
        return error('userId', 'please send user Id', res, 404);
      }
      const user = await prisma.user.findUnique({
        where: { id: req.params.userId },
      });
      if (!user) {
        return error('tripId', 'no trip found with this id', res, 404);
      }
      await prisma.user.delete({
        where: { id: user.id },
      });
      return res.json({ success: true });
    } catch (e) {
      return error('server', 'something went wrong', res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async updateOthers(req, res, next) {
    try {
      const { isAdmin, phoneNumber, fullName, isOrganizer } = req.body.updateData;

      if (!req.params.userId) {
        return error('userId', 'please send user Id', res, 404);
      }
      const user = await prisma.user.findUnique({
        where: { id: req.params.userId },
      });
      if (!user) {
        return error('userId', 'no user found with this id', res, 404);
      }

      const updateIsAdmin = !!isAdmin;
      const updatePhoneNumber = phoneNumber || user.phoneNumber;
      const updateFullName = fullName || user.fullName;

      const newUser = await prisma.user.update({
        where: { id: user.id },
        data: {
          isAdmin: updateIsAdmin,
          phoneNumber: updatePhoneNumber,
          fullName: updateFullName,
          isOrganizer: Boolean(isOrganizer)
        },
      });

      return res.json({ success: true, data: newUser });
    } catch (e) {
      return error('server', e, res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async addAdmin(req, res, next) {
    try {
      if (!req.body.phoneNumber) {
        console.log('found you');
        return error('phoneNumber', 'please send phone number', res);
      }

      if (!req.body.fullName) {
        return error('fullName', 'please send first name', res);
      }
      const [{ success, message, argument, value }] = allValidations([
        {
          type: VALIDATION_TYPE.PHONE_NUMBER,
          value: req.body.phoneNumber,
          argument: 'phoneNumber',
        },
      ]);
      const phoneNumber = value;
      console.log(req.body);
      const { fullName, isOrganizer, isAdmin } = req.body;
      if (!success) {
        return error(argument, message, res);
      }
      const userExists = await prisma.user.findUnique({
        where: { phoneNumber },
      });
      if (userExists) {
        return error('phoneNumber', 'user already exists', next, 409);
      }
      const user = await prisma.user.create({
        data: {
          phoneNumber,
          fullName,
          isAdmin: Boolean(isAdmin),
          isOrganizer: Boolean(isOrganizer),
        },
      });

      return res.json({
        success: true,
        data: user,
      });
    } catch (e) {
      console.log(e);
      return error('server', 'sign up failed please try again', res, 500);
    }
  }
  async getTickets(req, res, next) {
    const user = res.locals.user;
    const tnx = await prisma.tnx.findMany({
      where: {
        userId: user.id
      },
      include: {
        trip: {
          include: {
            organizerCommunity: true
          }
        }
      }
    })
    return res.json({ success: true, data: tnx })
  }
}
module.exports = new UserController();
