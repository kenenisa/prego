const { prisma, amplitudeClient } = require('../config');
const { VALIDATION_TYPE } = require('../config/constants');
const { error, groupBy } = require('../utils');
const { uploadCloudinary, uploadStream } = require('../utils/upload');
const { allValidations } = require('../utils/validation');
const fs = require('fs');
const path = require('path');
class TripController {
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async newTrip(req, res, next) {
    const inputFilter = {
      departure: {
        required: true,
        validate: VALIDATION_TYPE.DATE,
      },
      return: {
        required: true,
        validate: VALIDATION_TYPE.DATE,
      },
      name: {
        required: true,
      },
      destination: {
        required: true,
      },
      price: {
        required: true,
        validate: VALIDATION_TYPE.NUMBER,
      },
      meetUpLocation: {
        required: true,
      },
      categoryId: {
        required: true,
      },
      description: {
        required: false,
      },
      packageIncludes: {
        required: false,
        validate: VALIDATION_TYPE.ARRAY,
      },
      activities: {
        required: false,
        validate: VALIDATION_TYPE.ARRAY,
      },
      discountAmount: {
        required: false,
        validate: VALIDATION_TYPE.NUMBER,
      },
      discountPeople: {
        required: false,
        validate: VALIDATION_TYPE.NUMBER,
      },
    };
    for (let i in inputFilter) {
      if (inputFilter[i].required) {
        if (!req.body[i]) {
          return error(i, `${i} is required`, res);
        }
      }
      if (inputFilter[i].validate && req.body[i]) {
        const [{ success, message, value, argument }] = allValidations([
          {
            argument: i,
            type: inputFilter[i].validate,
            value: req.body[i],
          },
        ]);
        if (!success) {
          return error(i, message, res);
        }
        req.body[i] = value;
      }
    }
    const {
      departure,
      name,
      description,
      destination,
      price,
      meetUpLocation,
      activities,
      categoryId,
      discountAmount,
      discountPeople,
      isChildFriendly,
    } = req.body;
    const packageIncludes = req.body.packageIncludes || req.body.packageInclude
    const images = req.files || req.body.images
    const returnDate = req.body.return;
    try {
      if (!categoryId) {
        return error('categoryId', 'please send category Id', res, 404);
      }
      const category = await prisma.category.findUnique({
        where: {
          id: categoryId,
        },
      });
      if (!category) {
        return error('categoryId', 'no category exists with this id', res);
      }
      const imageLinks = []
      for (const image of images) {
        imageLinks.push(await uploadStream(image))
      }
      let communityId;
      if (req.body.communityId) {
        communityId = req.body.communityId
      } else {
        const community = await prisma.community.findFirst({
          where: {
            organizerId: res.locals.user.id,
          },
        });
        communityId = community.id
      }
      const discounted = Boolean(discountAmount);
      const trip = await prisma.trip.create({
        data: {
          departure,
          name,
          description,
          destination,
          price: Number(price) || 0,
          meetUpLocation,
          // categoryId,
          category: {
            connect: { id: categoryId }
          },
          discountAmount: Number(discountAmount) || null,
          discountPeople: Number(discountPeople) || null,
          discounted,
          // communityId: communityId,
          organizerCommunity: {
            connect: { id: communityId }
          },
          return: returnDate,
          image: imageLinks,
          isChildFriendly: Boolean(isChildFriendly),
          packageIncluded: {
            create: packageIncludes.split(',').map(pkg => ({
              assignedAt: new Date(),
              tripPackageIncluded: {
                connectOrCreate: {
                  where: {
                    name: pkg
                  },
                  create: {
                    name: pkg
                  }
                }
              }
            }))
          },
          activities: {
            create: activities.split(',').map(act => ({
              assignedAt: new Date(),
              tripActivities: {
                connectOrCreate: {
                  where: {
                    name: act
                  },
                  create: {
                    name: act
                  }
                }
              }
            }))
          },
          destination: {
            connectOrCreate: {
              where: {
                name: destination
              },
              create: {
                name: destination
              }
            }
          }
        }
      });
      amplitudeClient.logEvent({
        event_type: 'trip_creation',
        user_id: res.locals.user.phoneNumber,
        ip: '127.0.0.1',
      });
      return res.json({
        success: true,
        data: trip,
      });
    } catch (e) {
      console.log(e);
      return error('server', 'internal server error when trying to create trip', res);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async getTrips(req, res, next) {
    const {
      organizerId,
      categoryId,
      bookedBy,
      creatorId,
      limit,
      skip,
      q,
      upcoming,
      best_deals,
      detail,
    } = req.query;
    let filterLimit = Number(limit) || undefined;
    let filterSkip = Number(skip) || undefined;
    let addedOrderBy = {};
    let addedWhere = {};
    let addedInclude = {};
    if (upcoming === 'true') {
      addedOrderBy = {
        ...addedOrderBy,
        departure: 'desc',
      };
      addedWhere = {
        ...addedWhere,
        departure: { gt: new Date() },
      };
    }
    if (detail === 'true') {
      addedInclude = {
        bookedBy: true,
        organizer: true,
      };
    }
    if (best_deals === 'true') {
      addedOrderBy = {
        ...addedOrderBy,
        discountAmount: 'desc',
      };
      addedWhere = {
        ...addedWhere,
        discounted: true,
      };
    }
    try {
      const trips = await prisma.trip.findMany({
        where: {
          deletedStatus: false,
          organizerId: organizerId,
          categoryId: categoryId,
          bookedBy: bookedBy
            ? {
              some: {
                id: bookedBy,
              },
            }
            : {},
          // organizerUserId: creatorId,
          // OR: [],
          OR: q
            ? [
              { name: { contains: q, mode: 'insensitive' } },
              {
                description: {
                  contains: q,
                  mode: 'insensitive',
                },
              },
            ]
            : undefined,
          ...addedWhere,
        },
        skip: filterSkip,
        take: filterLimit,
        orderBy: {
          ...addedOrderBy,
        },
        include: {
          _count: true,
          // organizer: true,
          // organizer_user: true,
          organizerCommunity: true,
          category: true,
          packageIncluded: {
            include: {
              tripPackageIncluded: true
            }
          },
          activities: {
            include: {
              tripActivities: true
            }
          },
          destination: true,
          ...addedInclude,
        },
        // having: {
        //   ...(creatorId ?
        //     {
        //       organizerCommunity: {
        //         organizerId: creatorId
        //       }
        //     } : {})
        // }
      });
      const metaCount = await prisma.trip.count({
        where: { deletedStatus: false },
      });
      amplitudeClient.logEvent({
        event_type: 'get_trips',
        user_id: res.locals.user.phoneNumber,
        ip: '127.0.0.1',
      });
      return res.json({
        success: true,
        data: trips,
        meta: {
          total: metaCount,
        },
      });
    } catch (e) {
      console.log(e);
      return error('server', 'internal server error while getting trips', res);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async getWithId(req, res, next) {
    try {
      if (!req.params.tripId) {
        return error('tripId', 'please send trip Id', res, 404);
      }
      const trip = await prisma.trip.findUnique({
        where: {
          id: req.params.tripId,
        },
        include: {
          bookedBy: true,
          category: true,
          organizerCommunity: {
            include: {
              organizer: true
            }
          },
          packageIncluded: {
            include: {
              tripPackageIncluded: true
            }
          },
          activities: {
            include: {
              tripActivities: true
            }
          },
          destination: true,
        },
      });
      if (!trip) {
        return error('trip', 'no trip found with this id', res, 404);
      }
      return res.json({
        success: true,
        data: trip,
      });
    } catch (e) {
      return error(
        'server',
        'something went wrong in retrieving the community information',
        next,
        500,
      );
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async updateTrip(req, res, next) {
    if (!req.body.updateData) {
      return error('updateData', 'please send updateData', res);
    }
    if (!req.params.tripId) {
      return error('tripId', 'please send trip Id', res, 404);
    }
    const inputFilter = {
      departure: { validate: VALIDATION_TYPE.DATE },
      return: { validate: VALIDATION_TYPE.DATE },
      name: {},
      destination: {},
      price: { validate: VALIDATION_TYPE.NUMBER },
      meetUpLocation: {},
      categoryId: {},
      description: {},
      packageIncludes: { validate: VALIDATION_TYPE.ARRAY },
      activities: { validate: VALIDATION_TYPE.ARRAY },
      discountAmount: { validate: VALIDATION_TYPE.NUMBER },
      discountPeople: { validate: VALIDATION_TYPE.NUMBER },
      discounted: { validate: VALIDATION_TYPE.BOOLEAN },
    };
    for (let i in inputFilter) {
      if (inputFilter[i].validate && req.body.updateData[i]) {
        const [{ success, message, value }] = allValidations([
          {
            argument: i,
            type: inputFilter[i].validate,
            value: req.body.updateData[i],
          },
        ]);
        if (!success) {
          return error(i, message, res);
        }
        req.body.updateData[i] = value;
      }
    }
    const {
      departure,
      name,
      description,
      destination,
      price,
      meetUpLocation,
      packageIncludes,
      activities,
      categoryId,
      discountPeople,
      discountAmount,
      discounted,
    } = req.body.updateData;
    const returnDate = req.body.return;
    try {
      if (categoryId) {
        const category = await prisma.category.findUnique({
          where: {
            id: categoryId,
          },
        });
        if (!category) {
          return error('categoryId', 'no category exists with this id', res);
        }
      }
      const trip = await prisma.trip.findUnique({
        where: { id: req.params.tripId },
      });
      const updateDiscountAmount = discountAmount || trip.discountAmount;
      const updateDiscountPeople = discountPeople || trip.discountPeople;
      const tripUpdated = await prisma.trip.update({
        where: {
          id: req.params.tripId,
        },
        data: {
          departure,
          name,
          description,
          destination,
          price,
          meetUpLocation,
          packageIncludes,
          activities,
          categoryId,
          discountAmount: updateDiscountAmount,
          discountPeople: updateDiscountPeople,
          discounted,
          return: returnDate,
        },
      });
      return res.json({
        success: true,
        data: tripUpdated,
      });
    } catch (e) {
      console.log(e);
      return error('server', 'internal server error when trying to update trip', res);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async addImages(req, res, next) {
    try {
      const uploader = async (path) => await uploadCloudinary(path, 'Images');
      const urls = [];
      const { file } = req;
      const currPath = path.join(path.resolve(), 'tempFiles');
      const newPath = await uploader(`${currPath}/${file.filename}`);
      urls.push(newPath.secure_url);
      //?IMPORTANT delete after uploading to cloudinary
      fs.unlinkSync(`tempFiles/${file.filename}`);

      const trip = await prisma.trip.update({
        where: {
          id: req.params.tripId,
        },
        data: {
          image: {
            push: urls,
          },
        },
      });
      return res.json({
        success: true,
        data: trip,
      });
    } catch (e) {
      console.log(e);
      return error('server', 'upload failed please try again', res);
    }
  }
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async removeImage(req, res, next) {
    try {
      const { index } = req.body;
      if (!req.params.tripId) {
        return error('tripId', 'please send trip Id', res, 404);
      }
      const trip = await prisma.trip.findUnique({
        where: {
          id: req.params.tripId,
        },
        select: {
          image: true,
          id: true,
        },
      });
      let images = trip.image;
      images.splice(index, 1);
      await prisma.trip.update({
        where: { id: trip.id },
        data: {
          image: {
            set: images,
          },
        },
      });
      return res.json({
        success: true,
        data: trip,
      });
    } catch (e) {
      console.log(e);
      return error('server', 'internal server error when trying to create trip', res);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async activateTrip(req, res, next) {
    try {
      await prisma.trip.update({
        where: { id: req.params.tripId },
        data: { deletedStatus: false },
      });
      return res.json({ success: true });
    } catch (e) {
      return error('server', 'something went wrong', res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async deactivateTrip(req, res, next) {
    try {
      // await prisma.trip.update({
      //   where: { id: req.params.tripId },
      //   data: { deletedStatus: true },
      // });

      await prisma.trip.delete({
        where: { id: req.params.tripId },
      });
      return res.json({ success: true });
    } catch (e) {
      return error('server', 'something went wrong', res, 500);
    }
  }
  async getPackagesAndActivities(req, res, next) {
    try {

      return res.json({
        success: true, data: {
          packageIncludes: await prisma.tripPackageIncluded.findMany(),
          activities: await prisma.tripActivities.findMany(),
        }
      });
    } catch (e) {
      return error('server', 'something went wrong', res, 500);
    }
  }
  async browseTripsNoFilter() {
    const lastWeek = new Date(new Date().getTime() - (1000 * 60 * 60 * 24 * 7))
    return {
      this_week: await prisma.trip.findMany({
        where: {
          departure: {
            gt: lastWeek
          }
        },
        include: {
          organizerCommunity: true
        }
      }),
      other: await prisma.trip.findMany({
        where: {
          departure: {
            lt: lastWeek
          }
        },
        include: {
          organizerCommunity: true
        }
      })
    }
  }
  async browseTripsDateFilter(start, end) {
    return {
      other: await prisma.trip.findMany({
        where: {
          departure: {
            lte: new Date(end),
            gte: new Date(start),
          },
        },
        include: {
          organizerCommunity: true
        }
      })
    }
  }
  async browseTripsCommunityFilter() {
    const trips = await prisma.trip.findMany({
      include: {
        organizerCommunity: true
      }
    });
    return {
      groups: groupBy(trips, (trip) => trip.organizerCommunity.name)
    }
  }
  async browseTripsDestinationFilter() {
    const trips = await prisma.trip.findMany({
      include: {
        organizerCommunity: true,
        destination:true
      }
    });
    return {
      groups: groupBy(trips, (trip) => trip.destination.name)
    }
  }
  async browseTripsCategoryFilter() {
    const trips = await prisma.trip.findMany({
      include: {
        organizerCommunity: true,
        category: true
      }
    });
    return {
      groups: groupBy(trips, (trip) => trip.category.name)
    }
  }
  async browseTripsSearch(q) {
    const trips = await prisma.trip.findMany({
      where: {
        OR: [
          { name: { contains: q, mode: 'insensitive' } },
          {
            description: {
              contains: q,
              mode: 'insensitive',
            },
          },
          {
            destination: {
              contains: q,
              mode: 'insensitive',
            }
          }
        ]
      },
      include: {
        organizerCommunity: true,
        category: true
      }
    });
    return {
      other: trips
    }
  }
  async browseTrips(req, res, next) {
    try {
      const { filter, filterData } = req.body;
      let data = { this_week: [], groups: [], other: [] };
      let result = null
      const obj = new TripController()
      if (filter == 'date') {
        const { start, end } = filterData;
        result = await obj.browseTripsDateFilter(start, end)
      } else if (filter == 'community') {
        result = await obj.browseTripsCommunityFilter()
      } else if (filter == 'destination') {
        result = await obj.browseTripsDestinationFilter()
      } else if (filter == 'category') {
        result = await obj.browseTripsCategoryFilter()
      } else if (filter == 'search') {
        result = await obj.browseTripsSearch(filterData)
      } else {
        result = await obj.browseTripsNoFilter()
      }
      data = { ...data, ...result }

      return res.json({
        success: true,
        data
      })


    } catch (e) {
      console.log(e);
      return error('server', 'something went wrong', res, 500);
    }
  }
  async getTicketWithRef(req, res, next) {
    const { tnxRef } = req.params
    const data = await prisma.tnx.findUnique({
      where: {
        tnxRef,
      },
      include: {
        trip: {
          include: {
            organizerCommunity: {
              include: {
                organizer: true
              }
            }
          }
        },
        user: true
      }
    })
    return res.json({ success: !!data, data })
  }
}
module.exports = new TripController();
