const { prisma } = require('../config');
const { VALIDATION_TYPE } = require('../config/constants');
const { error } = require('../utils');
const { allValidations } = require('../utils/validation');
require('dotenv').config();
const { validGenders } = require('../utils');
const { sendSms } = require('../utils/sms');

class OrganizerClass {
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async auth(req, res, next) {
    try {
      if (!req.body.phoneNumber) {
        return error('phoneNumber', 'please send phone number', res);
      }
      if (!req.body.fullName) {
        return error('fullName', 'please send fullName', res);
      }
      if (!req.body.age) {
        return error('age', 'please send age', res);
      }
      if (!req.body.gender) {
        return error('gender', 'please send gender', res);
      }

      if (!validGenders.includes(req.body.gender.toLowerCase())) {
        return error('gender', 'Not valid gender', res);
      }
      const [{ success, message, argument, value }] = allValidations([
        {
          type: VALIDATION_TYPE.PHONE_NUMBER,
          value: req.body.phoneNumber,
          argument: 'phoneNumber',
        },
      ]);
      const phoneNumber = value;
      if (!success) return error(argument, message, res);
      const { fullName, age, gender } = req.body;
      const existOrganizer = await prisma.user.findUnique({
        where: { phoneNumber },
      });

      if (existOrganizer) {
        return error('phoneNumber', 'phone number already exist', res);
      }
      const newOrganizer = await prisma.user.create({
        data: {
          phoneNumber,
          isOrganizer: true,
          fullName,
          age,
          gender,
        },
      });
      const sms = await sendSms(phoneNumber);
      if (!sms.success) {
        await prisma.user.delete({ where: { id: newOrganizer.id } });
        return error('server', 'sms service failed', res, 500);
      }

      await prisma.user.update({
        where: { phoneNumber },
        data: {
          otp: sms.otp,
        },
      });

      return res.status(201).json({
        user: newOrganizer,
        message: 'Organizer signed up successfully please check your phone for otp',
      });
    } catch (e) {
      console.log(e);
      return error('server', 'sign up failed please try again', res, 500);
    }
  }
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async dashboard(req, res, next) {
    const user = res.locals.user;
    // const user = await prisma.user.findFirst({
    //   where: {
    //     id: '13328ef2-8f70-4ac2-b36c-5696a657b047'
    //   }
    // })
    const isOrganizer = user.isOrganizer;
    if (!isOrganizer) return error('organizer', 'You are not an organizer', res);
    const community = await prisma.community.findFirst({
      where: {
        organizerId: user.id,
      },
      include: {
        organizedTrips: {
          include: {
            bookedBy: true,
            Tnx: {
              include: {
                user: true
              }
            },
          },
        },
      },
    });
    console.log(community);
    if (!community) return error('organizer', "You don't have a community",res);
    return res.json(community);
  }
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async getTripDashboard(req, res, next) {
    const user = res.locals.user;
    // const user = await prisma.user.findFirst({
    //   where: {
    //     id: '13328ef2-8f70-4ac2-b36c-5696a657b047'
    //   }
    // })
    const isOrganizer = user.isOrganizer;
    if (!isOrganizer) return error('organizer', 'You are not an organizer', res);
    if (!req.params.tripId) {
      return error('tripId', 'please send trip Id', res, 404);
    }
    const trip = await prisma.trip.findFirst({
      where: {
        id: req.params.tripId,
      },
      include: {
        bookedBy: true,
        Tnx: {
          include: {
            user: true
          }
        },
      },
    });
    if (!trip) return error('organizer', "You don't have a community");
    return res.json(trip);
  }
}

module.exports = new OrganizerClass();
