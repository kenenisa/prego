const { prisma } = require('../config');
const { VALIDATION_TYPE } = require('../config/constants');
const { error } = require('../utils');
const { uploadFile, uploadStream } = require('../utils/upload');
const { allValidations } = require('../utils/validation');
const { uploadCloudinary } = require('../utils/upload');
const fs = require('fs');
const path = require('path');
const { default: Chapa } = require('chapa-node');
const { log } = require('console');
const chapaKey = process.env.CHAPA_KEY;
const chapa = new Chapa(chapaKey);

class CommunityController {
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async newCommunity(req, res, next) {
    const { name, bankCode, accountNumber, creator } = req.body;

    const image = req.file || req.body.file;
    if (!name)
      return error('name', 'please send name of your community', res);
    if (!bankCode) return error('bankCode', 'please send bank code', res);
    if (!accountNumber) return error('accountNumber', 'please send account number', res);
    if (!image) return error('image', 'please send image', res);
    if (await prisma.community.findUnique({ where: { name } })) return error('name', 'Community with this name already exists', res);
    const creatorUser = creator ?
      await prisma.user.findUnique({
        where: {
          id: creator
        }
      }) : res.locals.user;
    try {
      const imageLink = await uploadStream(image)

      const response = await chapa.createSubAccount({
        bank_code: bankCode,
        account_name: creatorUser.fullName,
        business_name: name,
        account_number: accountNumber,
        split_type: 'percentage',
        split_value: 0,
      });
      const subAccountId = response.data.subaccount_id;
      // const subAccountId = 'ABCD'
      const created = await prisma.community.create({
        data: {
          name,
          organizerId: creatorUser.id,
          bankCode,
          image: imageLink,
          accountNumber,
          subAccountId,
        },
      });
      return res.json({
        success: true,
        data: created,
      });
    } catch (e) {
      console.log(e);
      return error(
        'server',
        'internal server error while trying to create community, ' + e.message,
        res,
      );
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async getCommunities(req, res, next) {
    const { creatorId, managerId, tripId, followerId, limit, skip, q, popular } =
      req.query;
    let filterLimit = Number(limit) || undefined;
    let filterSkip = Number(skip) || undefined;
    let addedFiltersOrderBy = {};
    if (popular === 'true') {
      addedFiltersOrderBy = {
        ...addedFiltersOrderBy,
        // followers: { _count: 'desc' },
      };
    }
    try {
      const communities = await prisma.community.findMany({
        where: {
          creatorId: creatorId,
          deletedStatus: false,
          // managers: managerId
          //   ? {
          //     some: {
          //       id: managerId,
          //     },
          //   }
          //   : undefined,
          organizedTrips: tripId
            ? {
              some: {
                id: tripId,
              },
            }
            : undefined,
          // followers: followerId
          //   ? {
          //     some: {
          //       id: followerId,
          //     },
          //   }
          //   : undefined,
          OR: q
            ? [
              { name: { contains: q, mode: 'insensitive' } },
              {
                communityUsername: {
                  contains: q,
                  mode: 'insensitive',
                },
              },
              { bio: { contains: q, mode: 'insensitive' } },
            ]
            : undefined,
        },
        skip: filterSkip,
        take: filterLimit,
        orderBy: {
          ...addedFiltersOrderBy,
        },
        include: {
          _count: true,
          // bankAccounts: true,
          organizer: true,
          organizedTrips: true
          // followers: { take: 3 },
        },
      });
      const metaCount = await prisma.community.count({
        where: {
          deletedStatus: false,
        },
      });
      return res.json({
        success: true,
        data: communities,
        meta: {
          total: metaCount,
        },
      });
    } catch (e) {
      console.log(e);
      return error('server', 'internal server error while getting communities', res);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async getWithId(req, res, next) {
    try {
      if (!req.params.communityId) {
        return error('communityId', 'please send community Id', res, 404);
      }
      const community = await prisma.community.findUnique({
        where: {
          id: req.params.communityId,
        },
        include: {
          bankAccounts: true,
          creator: true,
          managers: true,
          followers: true,
          organizedTrips: true,
        },
      });
      if (!community) {
        return error('community', 'no community found with this id', res, 404);
      }
      return res.json({
        success: true,
        data: community,
      });
    } catch (e) {
      return error(
        'server',
        'something went wrong in retriving the community informations',
        next,
        500,
      );
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async updateCommunity(req, res, next) {
    if (!req.body.updateData) {
      return error('updateData', 'please send updateData', res);
    }
    const { name, bankCode, accountNumber, creator } = req.body.updateData;
    const imageLink = await uploadStream(image)

    const image = req.file || req.body.updateData.file;
    const inputBanks = bankAccounts
      ?.filter((elem) => elem.name && elem.number)
      ?.map((elem) => ({ name: elem.name, number: elem.number }));
    if (!req.params.communityId) {
      return error('communityId', 'please send community Id', res, 404);
    }
    const communityBeforeUpdate = await prisma.community.findUnique({
      where: {
        id: req.params.communityId,
      },
    });
    if (!communityBeforeUpdate) {
      return error('community', 'no commmunity exists with this id', res, 404);
    }
    if (communityUsername) {
      const [{ success, message, argument }] = allValidations([
        {
          type: VALIDATION_TYPE.COMMUNITY_USERNAME,
          value: communityUsername,
          argument: VALIDATION_TYPE.COMMUNITY_USERNAME,
        },
      ]);
      if (!success) {
        return error(argument, message, res);
      }
      const prevCom = await prisma.community.findFirst({
        where: {
          communityUsername: {
            equals: communityUsername,
            mode: 'insensitive',
          },
        },
      });
      if (prevCom && prevCom.id !== communityBeforeUpdate.id) {
        return error(argument, 'username already exists', next, 409);
      }
    }
    try {
      const allbanks = await chapa.getBanks();
      const bank_code = allbanks.data.find(({ name }) => name === inputBanks[0].name).id;

      const response = await chapa.createSubAccount({
        bank_code,
        account_name: name,
        business_name: communityUsername,
        account_number: inputBanks[0].number,
        split_type: 'percentage',
        split_value: '0.0',
      });
      const subaccountId = response.data.subaccount_id;

      const created = await prisma.community.update({
        where: {
          id: communityBeforeUpdate.id,
        },
        data: {
          name,
          communityUsername,
          bio,
          subaccountId,
          contactNumber,
          bankAccounts: inputBanks
            ? {
              deleteMany: {},
              createMany: {
                data: inputBanks || [],
                skipDuplicates: true,
              },
            }
            : {},
        },
        include: {
          bankAccounts: true,
        },
      });
      return res.json({
        success: true,
        data: created,
      });
    } catch (e) {
      console.log(e);
      return error(
        'server',
        'internal server error when trying to update community',
        next,
        500,
      );
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async updateProfile(req, res, next) {
    try {
      console.log('update profile');
      const uploader = async (path) => await uploadCloudinary(path, 'Images');
      const { file } = req;
      const currPath = path.join(path.resolve(), 'tempFiles');
      const newPath = await uploader(`${currPath}/${file.filename}`);
      const image = newPath.secure_url;
      //?IMPORTANT delete after uploading to cloudinary
      fs.unlinkSync(`tempFiles/${file.filename}`);

      const community = await prisma.community.update({
        where: { id: req.params.communityId },
        data: { image },
      });
      return res.json({
        success: true,
        data: community,
      });
    } catch (e) {
      return error('server', 'upload failed please try again', res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async updateBanner(req, res, next) {
    try {
      const banner = await uploadFile(req.file.path, 'COMMUNITY', res.locals.id, true);
      const community = await prisma.community.update({
        where: { id: req.params.communityId },
        data: { banner },
      });
      return res.json({
        success: true,
        data: community,
      });
    } catch (e) {
      return error('server', 'upload failed please try again', res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async activateCommunity(req, res, next) {
    try {
      await prisma.community.update({
        where: { id: req.params.communityId },
        data: { deletedStatus: false },
      });
      return res.json({ success: true });
    } catch (e) {
      return error('server', 'something went wrong', res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async deactivateCommunity(req, res, next) {
    try {
      // await prisma.community.update({
      //   where: { id: req.params.communityId },
      //   data: { deletedStatus: true },
      // });

      await prisma.community.delete({
        where: { id: req.params.communityId },
      });
      return res.json({ success: true });
    } catch (e) {
      return error('server', 'something went wrong', res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async addManagers(req, res, next) {
    const { managers } = req.body;
    if (!Array.isArray(managers)) {
      return error(
        'managers',
        'please send managers as an array of selected users to manage',
        next,
      );
    }
    console.log(managers, managers.length, !managers.length);
    if (!managers.length) {
      return error('managers', 'send at least 1 user to be manager', res);
    }
    try {
      const selectedManagers = await prisma.user.findMany({
        where: {
          OR: managers.map((elem) => ({ id: elem })),
          followedCommunities: {
            some: { id: req.params.communityId },
          },
        },
      });
      if (!selectedManagers.length) {
        return error(
          'managers',
          'send at least 1 user to be manager, and must be a follower of the community',
          next,
        );
      }
      await prisma.community.update({
        where: { id: req.params.communityId },
        data: {
          managers: {
            connect: selectedManagers.map((elem) => ({
              id: elem.id,
            })),
          },
        },
      });
      return res.json({ success: true });
    } catch (e) {
      return error('server', 'something went wrong', res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async removeManagers(req, res, next) {
    const { managers } = req.body;
    if (!Array.isArray(managers)) {
      return error(
        'managers',
        'please send managers as an array of selected users to manage',
        next,
      );
    }
    if (!managers.length) {
      return error('managers', 'send at least 1 user to be manager', res);
    }
    try {
      const selectedManagers = await prisma.user.findMany({
        where: {
          OR: managers.map((elem) => ({ id: elem })),
          managedCommunities: {
            some: { id: req.params.communityId },
          },
        },
      });
      if (!selectedManagers.length) {
        return error(
          'managers',
          'select at least 1 manager to be removed, user must be a manager of the community',
          next,
        );
      }
      const community = await prisma.community.update({
        where: { id: req.params.communityId },
        data: {
          managers: {
            disconnect: selectedManagers.map((elem) => ({
              id: elem.id,
            })),
          },
        },
      });
      return res.json({
        success: true,
        data: community,
      });
    } catch (e) {
      return error('server', 'something went wrong', res, 500);
    }
  }
}
module.exports = new CommunityController();
