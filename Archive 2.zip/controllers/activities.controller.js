const { prisma } = require('../config');
const { error } = require('../utils');
class ActivitiesController {
    /**
     *
     * @param {import("express").Request} req
     * @param {import("express").Response} res
     * @param {import("express").NextFunction} next
     * @returns
     */
    async newActivities(req, res, next) {
        const { name } = req.body;
        if (!name) {
            return error('name', 'activities name is required', res);
        }
        try {
            const created = await prisma.tripActivities.create({
                data: {
                    name,
                },
            });
            return res.json({
                success: true,
                data: created,
            });
        } catch (e) {
            console.log(e);
            return error(
                'server',
                'internal server error when trying to create activities',
                next,
            );
        }
    }
    /**
     *
     * @param {import("express").Request} req
     * @param {import("express").Response} res
     * @param {import("express").NextFunction} next
     * @returns
     */
    async getActivities(req, res, next) {
        const { limit, skip } = req.query;
        let filterLimit = Number(limit) || undefined;
        let filterSkip = Number(skip) || undefined;
        try {
            return res.json({
                success: true,
                meta: {
                    total: await prisma.tripActivities.count(),
                },
                data: await prisma.tripActivities.findMany({
                    take: filterLimit,
                    skip: filterSkip,
                    include: {
                        _count: true,
                    }
                }),
            });
        } catch (e) {
            console.log(e);
            return error(
                'server',
                'internal server error when trying to create activities',
                next,
            );
        }
    }
    /**
     *
     * @param {import("express").Request} req
     * @param {import("express").Response} res
     * @param {import("express").NextFunction} next
     * @returns
     */
    async updateActivities(req, res, next) {
        if (!req.body.updateData) {
            return error('updateData', 'please send updateData', res);
        }
        const { name } = req.body.updateData;
        try {
            if (!req.params.activitiesId) {
                return error('activitiesId', 'please send activities Id', res, 404);
            }
            const activities = await prisma.tripActivities.findUnique({
                where: { id: req.params.activitiesId },
            });
            if (!activities) {
                return error('activitiesId', 'no activities exists with this id', res, 404);
            }
            const updated = await prisma.tripActivities.update({
                where: { id: activities.id },
                data: { name },
            });
            return res.json({
                success: true,
                data: updated,
            });
        } catch (e) {
            console.log(e);
            return error(
                'server',
                'internal server error when trying to update activities',
                next,
            );
        }
    }
    /**
     *
     * @param {import("express").Request} req
     * @param {import("express").Response} res
     * @param {import("express").NextFunction} next
     * @returns
     */
    async deleteActivities(req, res, next) {
        try {
            if (!req.params.activitiesId) {
                return error('activities', 'please send activities Id', res, 404);
            }
            const activities = await prisma.tripActivities.findUnique({
                where: { id: req.params.activitiesId },
            });
            if (!activities) {
                return error('activitiesId', 'no activities exists with this id', res, 404);
            }
            // if (category.trip.length) {
            //   return error(
            //     'trip',
            //     "can't delete a category if it has trips registered under it",
            //     next,
            //   );
            // }
            const deleted = await prisma.tripActivities.delete({
                where: { id: activities.id },
            });
            return res.json({
                success: true,
                data: deleted,
            });
        } catch (e) {
            console.log(e);
            return error(
                'server',
                'internal server error when trying to delete category',
                next,
            );
        }
    }
}
module.exports = new ActivitiesController();
