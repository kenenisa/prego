const { prisma } = require('../config');
const { error } = require('../utils');

class TnxController {
  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async getTnxs(req, res, next) {
    const { limit, skip, q } = req.query;
    let filterLimit = Number(limit) || undefined;
    let filterSkip = Number(skip) || undefined;

    try {
      const trips = await prisma.tnx.findMany({
        where: {
          OR: q
            ? [
                { name: { contains: q, mode: 'insensitive' } },
                {
                  description: {
                    contains: q,
                    mode: 'insensitive',
                  },
                },
              ]
            : undefined,
        },
        skip: filterSkip,
        take: filterLimit,

        include: {
          trip: true,
        },
      });

      const metaCount = await prisma.tnx.count();

      //   amplitudeClient.logEvent({
      //     event_type: 'get_trips',
      //     user_id: res.locals.user.phoneNumber,
      //     ip: '127.0.0.1',
      //   });

      return res.json({
        success: true,
        data: trips,
        meta: {
          total: metaCount,
        },
      });
    } catch (e) {
      console.log(e);
      return error('server', 'internal server error while getting trips', res);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async getWithId(req, res, next) {
    try {
      if (!req.params.tnxId) {
        return error('tnxId', 'please send transaction Id', res, 404);
      }
      const tnx = await prisma.tnx.findUnique({
        where: {
          id: req.params.tripId,
        },
        include: {
          trip: true,
        },
      });
      if (!tnx) {
        return error('tnx', 'no transaction found with this id', res, 404);
      }
      return res.json({
        success: true,
        data: tnx,
      });
    } catch (e) {
      return error(
        'server',
        'something went wrong in retriving the community informations',
        next,
        500,
      );
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async approveTnx(req, res, next) {
    try {
      if (!req.params.tnxId) {
        return error('tripId', 'please send trip Id', res, 404);
      }
      const { tnxId } = req.params;
      const tnx = await prisma.tnx.findUnique({
        where: { id: tnxId },
      });
      if (!tnx) {
        return error('tnxId', 'no transaction found with this id', res, 404);
      }

      await prisma.tnx.update({
        where: {
          id: tnxId,
        },
        data: {
          isPaid: true,
        },
      });

      return res.json({ success: true, data: tnx });
    } catch (e) {
      return error('server', e, 'something went wrong', res, 500);
    }
  }

  /**
   *
   * @param {import("express").Request} req
   * @param {import("express").Response} res
   * @param {import("express").NextFunction} next
   * @returns
   */
  async deleteTnx(req, res, next) {
    try {
      // await prisma.tnx.update({
      //   where: { id: req.params.tnxId },
      //   data: { deletedStatus: true },
      // });

      await prisma.tnx.delete({
        where: { id: req.params.tnxId },
      });
      return res.json({ success: true });
    } catch (e) {
      console.log(e);
      return error('server', 'something went wrong', res, 500);
    }
  }
}
module.exports = new TnxController();
