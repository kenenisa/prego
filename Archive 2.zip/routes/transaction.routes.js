const express = require('express');
const { isAdmin, authenticate } = require('../auth/authenticate');
const tnxController = require('../controllers/transaction.controller');
const router = express.Router();

router.get('/', authenticate, isAdmin, tnxController.getTnxs);
router.get('/:tnxId', authenticate, isAdmin, tnxController.getWithId);
router.patch('/:tnxId', authenticate, isAdmin, tnxController.approveTnx);
router.delete('/:tnxId', authenticate, isAdmin, tnxController.deleteTnx);

module.exports = router;
