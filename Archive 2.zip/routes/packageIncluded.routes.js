const express = require('express');
const { authenticate, isAdmin } = require('../auth/authenticate');
const {
    deletePackageIncluded,
    getPackageIncluded,
    newPackageIncluded,
    updatePackageIncluded,
} = require('../controllers/packageIncluded.controller');
const router = express.Router();

router.post('/', authenticate, isAdmin, newPackageIncluded);
router.get('/', authenticate, getPackageIncluded);
router.patch('/:packageIncludedId', authenticate, isAdmin, updatePackageIncluded);
router.delete('/:packageIncludedId', authenticate, isAdmin, deletePackageIncluded);
module.exports = router;
