const express = require('express');
const { authenticate, isAdmin, isOrganizer } = require('../auth/authenticate');
const { uploadMulter } = require('../utils/upload');
const {
  addImages,
  getTrips,
  getWithId,
  newTrip,
  removeImage,
  updateTrip,
  activateTrip,
  deactivateTrip,
  getPackagesAndActivities,
  browseTrips,
  getTicketWithRef
} = require('../controllers/trip.controller');
const { tripManager } = require('../middlewares/trip.middlewares');
const router = express.Router();
const multer = require('multer');
const { getDestinations } = require('../controllers/destinations.controller');
const upload = multer();

router.post('/', upload.array('images'), authenticate, isOrganizer, newTrip);
router.get('/', authenticate, getTrips); //all trips, apply filters and stuff in the resolver
router.get('/packagesAndActivities', authenticate, getPackagesAndActivities); //all trips, apply filters and stuff in the resolver
router.get('/destinations', authenticate, getDestinations); //all trips, apply filters and stuff in the resolver
router.get('/:tripId', getWithId); //a single trip, apply filters and stuff in the resolver
router.patch('/:tripId', authenticate, isOrganizer, updateTrip);
router.patch(
  '/add-images/:tripId',
  authenticate,
  tripManager,
  uploadMulter.single('image'),
  addImages,
);
router.patch('/remove-image/:tripId', authenticate, tripManager, removeImage);
router.delete('/disable-trip/:tripId', authenticate, tripManager, deactivateTrip);
router.post('/enable-trip/:tripId', authenticate, tripManager, activateTrip);
router.delete('/admin/disable-trip/:tripId', authenticate, isAdmin, deactivateTrip);
router.post('/admin/enable-trip/:tripId', authenticate, isAdmin, deactivateTrip);

router.post('/browse', browseTrips);
router.get('/receipt/:tnxRef', authenticate, getTicketWithRef)

module.exports = router;
