const express = require('express');
const { authenticate, isAdmin, verifyTempToken } = require('../auth/authenticate');
const UserController = require('../controllers/user.controller');
const { loginAdmin, dashboard } = require('../controllers/admin.controller');

const router = express.Router();
const multer = require('multer');
const { addAdmin } = require('../controllers/user.controller');
const { prisma } = require('../config');
const upload = multer({ dest: 'tempFiles/' });
const {
  auth,
  resendOTP,
  getMe,
  updatePassword,
  updateSelf,
  getAll,
  getWithId,
  bookTrip,
  followCommunity,
  unBookTrip,
  unFollowCommunity,
  activateUser,
  deactivateUser,
  removeUser,
  updateBanner,
  updateProfile,
  updateOthers,
  verifyOTP,
  login,
  getTickets
} = UserController;

// auth actions
router.post('/login', login);
router.post('/auth', auth);
router.post('/verify-otp', verifyOTP);
router.post('/resend-otp', resendOTP);

//#region self Actions
router.patch('/', authenticate, updateSelf); //update self
router.patch('/change-profile', authenticate, upload.single('profile'), updateProfile);
router.patch('/change-banner', authenticate, upload.single('banner'), updateBanner);
router.get('/me', authenticate, getMe); //get all data about me, include everything
router.get('/tickets', authenticate, getTickets);
router.get('/otp', async (req, res, next) => {
  const user = await prisma.user.findFirst({
    where: {
      phoneNumber: '0973047942'
    }
  })
  return res.send(user.otp)
})
//#endregion

//#region social actions
router.get('/', authenticate, getAll); //all users
router.get('/:userId', authenticate, getWithId); //a single user
router.post('/follow/:communityId', authenticate, followCommunity);
router.post('/un-follow/:communityId', authenticate, unFollowCommunity);
router.post('/book-trip/:tripId', bookTrip);
router.post('/unbook-trip/:tripId', authenticate, unBookTrip);

//#region admin actions
// router.post("/add-user", authenticate, isAdmin, login); //skipped
router.post('/admin/login', loginAdmin);
router.post('/', authenticate, isAdmin, addAdmin);
router.patch('/:userId', authenticate, isAdmin, updateOthers); //update self
router.post('/activate-user/:userId', authenticate, isAdmin, activateUser);
router.delete('/suspend-user/:userId', authenticate, isAdmin, deactivateUser);
router.delete('/remove-user/:userId', authenticate, isAdmin, removeUser);

router.get('/admin/dashboard', authenticate, isAdmin, dashboard);

// router.patch("/update-user/:userId", authenticate, isAdmin, login); //not allowed hopefully
//#endregion
module.exports = router;
