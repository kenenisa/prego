const express = require('express');
const { authenticate, isAdmin, isOrganizer } = require('../auth/authenticate');
const {
  activateCommunity,
  addManagers,
  deactivateCommunity,
  getCommunities,
  getWithId,
  newCommunity,
  removeManagers,
  updateBanner,
  updateCommunity,
  updateProfile,
} = require('../controllers/community.controller');
const router = express.Router();

const {
  communityManager,
  communityCreator,
} = require('../middlewares/community.middlewares');
const { uploadMulter } = require('../utils/upload');
const multer = require('multer');
const upload = multer();

router.post('/', upload.single('file'), authenticate, isOrganizer, newCommunity);
router.get('/', authenticate, getCommunities); //get all communities
router.get('/:communityId', authenticate, getWithId); //get a single community
router.patch('/:communityId', authenticate, communityManager, updateCommunity);
router.patch(
  '/add-images/:communityId',
  authenticate,
  communityManager,
  uploadMulter.single('image'),
  updateProfile,
);
router.patch(
  '/change-banner/:communityId',
  authenticate,
  communityManager,
  // upload.single('banner'),
  updateBanner,
);
router.delete(
  '/deactivate-community/:communityId',
  authenticate,
  communityCreator,
  deactivateCommunity,
);
router.post(
  '/activate-community/:communityId',
  authenticate,
  communityCreator,
  activateCommunity,
);
router.post('/add-managers/:communityId', authenticate, communityCreator, addManagers);
router.post(
  '/remove-manager/:communityId',
  authenticate,
  communityCreator,
  removeManagers,
);

router.delete(
  '/admin/deactivate-community/:communityId',
  authenticate,
  isAdmin,
  deactivateCommunity,
);
router.post(
  '/admin/activate-community/:communityId',
  authenticate,
  isAdmin,
  activateCommunity,
);

module.exports = router;
