const express = require('express');
const organizerController = require('../controllers/organizer.controller');
const { authenticate } = require('../auth/authenticate');
const router = express.Router();

const { auth, dashboard, getTripDashboard } = organizerController;

// auth actions
router.post('/auth', auth);
router.get('/dashboard', authenticate, dashboard);
router.get('/dashboard/:tripId', authenticate, getTripDashboard);

module.exports = router;
