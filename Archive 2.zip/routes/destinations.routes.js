const express = require('express');
const { authenticate, isAdmin } = require('../auth/authenticate');
const {
    deleteDestinations,
    getDestinations,
    newDestinations,
    updateDestinations,
} = require('../controllers/destinations.controller');
const router = express.Router();

router.post('/', authenticate, isAdmin, newDestinations);
router.get('/', authenticate, getDestinations);
router.patch('/:destinationsId', authenticate, isAdmin, updateDestinations);
router.delete('/:destinationsId', authenticate, isAdmin, deleteDestinations);
module.exports = router;
