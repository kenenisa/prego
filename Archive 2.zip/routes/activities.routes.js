const express = require('express');
const { authenticate, isAdmin } = require('../auth/authenticate');
const {
    deleteActivities,
    getActivities,
    newActivities,
    updateActivities,
} = require('../controllers/activities.controller');
const router = express.Router();

router.post('/', authenticate, isAdmin, newActivities);
router.get('/', authenticate, getActivities);
router.patch('/:activitiesId', authenticate, isAdmin, updateActivities);
router.delete('/:activitiesId', authenticate, isAdmin, deleteActivities);
module.exports = router;
