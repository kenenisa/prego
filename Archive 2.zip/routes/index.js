const express = require('express');
const router = express.Router();

const categoryRoutes = require('./category.routes');
const communityRoutes = require('./community.routes');
const tripRoutes = require('./trip.routes');
const userRoutes = require('./user.routes');
const chapaRoutes = require('./chapa.routes');
const tnxroutes = require('./transaction.routes');
const organizerRoutes = require('./organizer.routes');
const packageIncluded = require('./packageIncluded.routes');
const activities = require('./activities.routes');
const destinations = require('./destinations.routes');
const { main } = require('../prisma/seed');
const { prisma } = require('../config');

router.use('/categories', categoryRoutes);
router.use('/trips', tripRoutes);
router.use('/communities', communityRoutes);
router.use('/users', userRoutes);
router.use('/chapa', chapaRoutes);
router.use('/tnxs', tnxroutes);
router.use('/organizers', organizerRoutes);
router.use('/packageInclude', packageIncluded);
router.use('/activities', activities);
router.use('/destinations', destinations);
router.get('/startdb', async (req, res, next) => {
    res.json(
        await prisma.user.update({
            where: {
                id: '13328ef2-8f70-4ac2-b36c-5696a657b047'
            },
            data: {
                phoneNumber: '0973047942',
                isOrganizer: true
            }
        }))
    // return await main()
})

module.exports = router;
