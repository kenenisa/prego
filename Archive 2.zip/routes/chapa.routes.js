const express = require('express');
const { authenticate } = require('../auth/authenticate');

const {
    initializePayment,
    initializePayLater,
    update,
    webHook,
    verify,
    bankCodes
} = require('../controllers/chapa.controller');
const router = express.Router();

router.post('/pay/:id', authenticate, initializePayment);
router.post('/payLater/:id', authenticate, initializePayLater);
router.get('/bankCodes', bankCodes);
router.get('/update/:tnxRef', update);
router.post('/webhook', webHook);
router.get('/verify/:tnxRef', verify);

module.exports = router;
