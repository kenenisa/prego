const { prisma } = require('../config');
// const { VALIDATION_TYPE } = require("../config/constants");
const { error } = require('../utils');
// const { validatePhoneNumber, allValidations } = require("../utils/validation");

class UserServices {
  async updateUser(updatedUserId, bodyUpdateData, next) {
    const { username, firstName, lastName, email, bio } = bodyUpdateData;
    const updateData = { username, firstName, lastName, email, bio };
    if (!Object.keys(updateData).length) {
      return error('updateData', 'please send updateData', res);
    }
    const previousUser = await prisma.user.findFirst({
      where: {
        OR: [
          { username: { equals: username, mode: 'insensitive' } },
          { email: { equals: username, mode: 'insensitive' } },
        ],
      },
    });
    if (previousUser && previousUser.id !== updatedUserId) {
      const arg = previousUser.username === username ? 'username' : 'email';
      return error(arg, `user with the same ${arg} already exists`, res);
    }
    try {
      const updatedUser = await prisma.user.update({
        where: {
          id: updatedUserId,
        },
        data: updateData,
      });
      return { success: true, updateData: updatedUser };
    } catch (e) {
      console.log(e);
      return error(
        'server',
        'something went wrong updating user, try again later',
        next,
        500,
      );
    }
  }
  async getOneUser(id, res) {
    try {
      if (!id) {
        return error('user', 'please send id', res, 404);
      }
      const user = await prisma.user.findUnique({
        where: {
          id: id,
        },
        include: {
          bookedTrips: true,
          communities: true,
        },
      });
      if (!user) {
        return error('user', 'no user found with this id', res, 404);
      }
      return {
        success: true,
        data: user,
      };
    } catch (e) {
      console.log(e);
      return error(
        'server',
        'something went wrong in retriving the account informations',
        res,
        500,
      );
    }
  }
}
module.exports = new UserServices();
