cd ../web
npm run build
cp -r ./build/ ../api/public/
cd ../admin
npm run build
cp -r ./build/ ../api/public/admin/
