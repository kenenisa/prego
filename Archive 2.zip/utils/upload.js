const path = require('path');
const { cloudinary } = require('../config');
const multer = require('multer');
const fs = require('fs');

/**
 *
 * @param {string} filePath path of file given by multer
 * @param {"USER"|"COMMUNITY"|"TRIP"} type type of uploaded file
 * @param {string} id id of type for file saving
 */

const uploadCloudinary = (file, folder) => {
  folder
  return new Promise((resolve) => {
    resolve(
      cloudinary.uploader.upload(file, {
        unique_filename: false,
        use_filename: true,
        overwrite: true,
      }),
    );
  });
};

const storage = multer.diskStorage({
  destination(_req, _file, cb) {
    const uploadPath = 'tempFiles/';
    !fs.existsSync(uploadPath) && fs.mkdirSync(uploadPath);
    cb(null, uploadPath);
  },
  filename(_req, file, cb) {
    cb(null, `${file.fieldname}-${Date.now()}${path.extname(file.originalname)}`);
  },
});

/**
 * Check if a file type matches one of the expected extensions (images only)
 * @param file
 * @param cb
 */
function checkFileType(file, cb) {
  const filetypes = /jpg|jpeg|png/;
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  const mimetype = filetypes.test(file.mimetype);

  if (extname && mimetype) {
    return cb(null, true);
  } else {
    cb(Error('Images only!'));
  }
}

const uploadMulter = multer({
  storage,
  fileFilter: function (_req, file, cb) {
    checkFileType(file, cb);
  },
});
const uploadStream = (file) => {
  return new Promise((resolve, reject) => {
    cloudinary.uploader.upload_stream({ resource_type: 'image' }, (error, result) => {
      if (error) reject(error);
      resolve(result.secure_url);
    }).end(file.buffer);
  })
}
module.exports = { uploadCloudinary, uploadMulter, uploadStream };
