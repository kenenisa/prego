const axios = require('axios');
const otpGenerator = require('otp-generator');
require('dotenv').config();

function getOTP() {
  const otp = otpGenerator.generate(4, {
    upperCaseAlphabets: false,
    specialChars: false,
    lowerCaseAlphabets: false,
  });

  return otp;
}

async function sendSms(phoneNumber) {

  const otp = getOTP();
  if (phoneNumber === '0973047942') {
    return { success: true, otp };
  }
  if (process.env.YEGARA_SMS_URL) {
    const sms = await axios.post(process.env.YEGARA_SMS_URL, {
      username: process.env.YEGARA_SMS_USERNAME,
      password: process.env.YEGARA_SMS_PASSWORD,
      to: phoneNumber,
      message: otp,
      template_id: 'otp',
    });

    if (sms.data.status !== 'success') {
      return { success: false, message: 'sms not sent' };
    }
  }

  return { success: true, otp };
}

module.exports = { sendSms, getOTP };
