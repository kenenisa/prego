const fs = require('fs');

/**
 *
 * @param {string} key argument of the error
 * @param {string|Array<string>} message error message to send client
 * @param {Function} next the next middleware function of express
 * @param {number} status status of the error(default 400)
 */
const error = (key, message, res, status = 400) => {
  let myError = { status, message, argument: key };
  status != 400 && console.log({ error: myError });
  // next();
  // next(new Error(JSON.stringify(myError)));
  // return false;
  res.status(status).json(myError)
  return false
  // return JSON.stringify(myError);
};
const makeEnvExample = () => {
  let writtenEnv = fs.readFileSync('.env', 'utf8');
  writtenEnv = writtenEnv.replace(/=.*/g, '=your_value_here');
  // for (let i in process.env) {
  //     writtenEnv += `${i}=your_value_here\n`;
  // }
  fs.writeFileSync('.env.example', writtenEnv);
  console.log('env file written');
};
const validGenders = ['male', 'female'];


const groupBy = (arr, callback) => {
  const reduced = arr.reduce((x, y) => {
    const field = callback(y);
    (x[field] = x[field] || []).push(y);
    return x;
  }, {});
  const result = []
  for (const r in reduced) {
    result.push({ name: r, value: reduced[r] })
  }
  return result
}
module.exports = { error, makeEnvExample, validGenders, groupBy };
