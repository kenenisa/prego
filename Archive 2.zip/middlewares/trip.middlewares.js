const { prisma } = require('../config');
const { error } = require('../utils');

/**
 *
 * @param {import("express").Request} req
 * @param {import("express").Response} res
 * @param {import("express").NextFunction} next
 */
const tripManager = async (req, res, next) => {
  const tripId = req.params.tripId;
  if (!tripId) {
    return error('tripId', 'Please send trip id in the param', res, 404);
  }
  const trip = await prisma.trip.findUnique({
    where: { id: tripId },
    include: { organizer: { include: { managers: true } } },
  });
  if (!trip) {
    return error('trip', 'no trip exists with this id', res, 404);
  }
  if (trip.deletedStatus) {
    return error('trip', 'this trip has been removed! please contact admins', res, 404);
  }
  if (trip.organizer.creatorId === res.locals.id) {
    return next();
  }
  for (let i in trip.organizer.managers) {
    if (trip.organizer.managers[i].id === res.locals.id) {
      return next();
    }
  }
  return error('user', 'you are unauthorized for this action', next, 403);
};
module.exports = { tripManager };
