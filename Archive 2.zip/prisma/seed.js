const { faker } = require('@faker-js/faker');
const { prisma } = require('../config');
const fs = require('fs');
let user;
const addUsers = async () => {
  const otp = '1234';
  //create admin
  await prisma.user.create({
    data: {
      fullName: 'admin',
      otp,
      phoneNumber: '0912345678',
      isAdmin: true,
    },
  });
  //create normal users
  await prisma.user.createMany({
    data: Array(20)
      .fill(2)
      .map(() => ({
        fullName: faker.name.firstName(),
        phoneNumber: faker.phone.number(),
        isAdmin: false,
      })),
    skipDuplicates: true,
  });
};
const addCommunities = async () => {
  const users = await prisma.user.findMany({ select: { id: true } });
  await prisma.community.createMany({
    skipDuplicates: true,
    data: Array(10)
      .fill(2)
      .map(() => ({
        image: faker.internet.avatar(),
        name: faker.animal.bird(),
        bankCode: 'abc',
        organizerId: users[Math.floor(Math.random() * users.length)].id,
        accountNumber: 'abcd',
        subAccountId: 'abcde'
      })),
  });
};

const addCategories = async () => {
  await prisma.category.createMany({
    data: Array(4)
      .fill(2)
      .map(() => ({
        name: faker.random.word(),
        description: faker.lorem.sentence(),
      })),
  });
};

const addTrips = async () => {
  const categories = await prisma.category.findMany();
  const communities = await prisma.community.findMany({
    select: {
      id: true,
    },
  });
  // await prisma.trip.createMany({
  //   skipDuplicates: true,
  //   data: 
  for (const trip of
    Array(20)
      .fill(20)
      .map((_, index) => {
        const chosenCommunity = communities[parseInt(Math.random() * 4)];
        const departure = faker.date.between({ from: new Date('1/9/2023'), to: new Date('15/29/2023') });
        return {
          categoryId: categories[parseInt(Math.random() * 4)].id,
          departure,
          return: faker.date.between({ from: new Date(departure), to: new Date('10/30/2023') }),
          destination: faker.address.city(),
          discountAmount: index % 2 === 0 ? parseFloat(faker.random.numeric(3)) : null,
          discounted: index % 2 === 0,
          meetUpLocation: faker.address.city(),
          name: faker.company.name(),
          communityId: chosenCommunity.id,
          description: faker.lorem.sentence(),
          image: faker.helpers.arrayElements(
            Array(Math.floor(10 * Math.random()) + 1)
              .fill(2)
              .map(() => faker.image.imageUrl()),
          ),
          isChildFriendly: index % 3 == 0,
          packageIncluded: {
            create: Array(Math.floor(10 * Math.random()))
              .fill(2)
              .map(() => faker.random.word())
              .map(pkg => ({
                assignedAt: new Date(),
                tripPackageIncluded: {
                  connectOrCreate: {
                    where: {
                      name: pkg
                    },
                    create: {
                      name: pkg
                    }
                  }
                }
              }))
          },
          activities: {
            create: Array(Math.floor(10 * Math.random()))
              .fill(2)
              .map(() => faker.random.word()).map(act => ({
                assignedAt: new Date(),
                tripActivities: {
                  connectOrCreate: {
                    where: {
                      name: act
                    },
                    create: {
                      name: act
                    }
                  }
                }
              }))
          },
          price: parseFloat(faker.random.numeric(4)),
        };
      })) {
    // console.log(trip);
    try {
      await prisma.trip.create({ data: trip })
    } catch (e) {
      console.log(e)
    }
  }
  // });
};
const main = async () => {
  // console.log("await addCategories()");
  // await addCategories();
  // console.log("await addUsers()");
  // await addUsers();
  // console.log("await addCommunities()");
  // await addCommunities();
  // console.log('await addTrips()');
  // await addTrips();
  const fs = require('fs')
  const data = JSON.parse(fs.readFileSync('./prisma/trips.json').toString())
  console.log(data.length);
  let x = 1
  for (const d of data) {
    //find or create user
    console.log(x);
    x += 1
    await prisma.user.upsert({
      where: {
        id: d['organizer_user.id']
      },
      update: {
        fullName: d['organizer_user.firstName'] + ' ' + d['organizer_user.lastName'],
        phoneNumber: d["organizer_user.phoneNumber"].toString()
      },
      create: {
        id: d['organizer_user.id'],
        fullName: d['organizer_user.firstName'] + ' ' + d['organizer_user.lastName'],
        phoneNumber: d["organizer_user.phoneNumber"].toString()
      }
    })
    //find or create category
    await prisma.category.upsert({
      where: {
        id: d['category.id']
      },
      update: {
        name: d['category.name'],
        description: d['category.description'],
      },
      create: {
        id: d['category.id'],
        name: d['category.name'],
        description: d['category.description'],
      }
    })
    // find or create community
    await prisma.community.upsert({
      where: {
        id: d['organizer.id']
      },
      update: {
        name: d['organizer.communityUsername'],
        bankCode: '853d0598-9c01-41ab-ac99-48eab4da1513',
        subAccountId: '5cfa680d-2018-4f37-a117-ecfb6c84ca55',
        accountNumber: '0900112233',
        image: d['organizer.image'],
        organizerId: d['organizer_user.id']
      },
      create: {
        id: d['organizer.id'],
        name: d['organizer.communityUsername'],
        bankCode: '853d0598-9c01-41ab-ac99-48eab4da1513',
        subAccountId: '5cfa680d-2018-4f37-a117-ecfb6c84ca55',
        accountNumber: '0900112233',
        image: d['organizer.image'],
        organizerId: d['organizer_user.id']
      }
    })
    const discounted = d['discounted'] === 'TRUE'
    //find or create trips
    await prisma.trip.upsert({
      where: { id: d['id'] },
      update: {
        image: [d['image']],
        name: d['name'],
        departure: d['departure'],
        return: d['return'],
        description: d['description'],
        destination: {
          connectOrCreate: {
            where: {
              name: d['destination']
            },
            create: {
              name: d['destination']
            }
          }
        },
        price: d['price'],
        meetUpLocation: d['meetUpLocation'],
        categoryId: d['categoryId'],
        discounted,
        communityId: d['organizer.id'],
        categoryId: d['category.id'],
        isChildFriendly: true,
        ...(discounted ? { discountAmount: d['discountAmount'] } : {})

      },
      create: {
        id: d['id'],
        image: [d['image']],
        name: d['name'],
        departure: d['departure'],
        return: d['return'],
        description: d['description'],
        destination: {
          connectOrCreate: {
            where: {
              name: d['destination']
            },
            create: {
              name: d['destination']
            }
          }
        },
        price: d['price'],
        meetUpLocation: d['meetUpLocation'],
        categoryId: d['categoryId'],
        discounted,
        communityId: d['organizer.id'],
        categoryId: d['category.id'],
        isChildFriendly: true,
        ...(discounted ? { discountAmount: d['discountAmount'] } : {})
      }
    })
  }

  // community: 7f351818-37f2-4372-9734-5ed60106c1b2
  const com = await prisma.community.findUnique({
    where: {
      id: '7f351818-37f2-4372-9734-5ed60106c1b2'
    },
    include: {
      organizedTrips: true,
      organizer: true
    }
  })
  console.log(com.organizer);
  // const users = await prisma.user.findMany()
  // for (const trip of com.organizedTrips) {
  //   let i = Math.floor(Math.random() * 10);
  //   while (i > 0) {
  //     const paid = Math.random() > 0.5;
  //     const userId = Math.floor(Math.random() * users.length)
  //     await prisma.tnx.create({
  //       data: {
  //         ...(paid ? {
  //           isPaid: true,
  //           amount: trip.price,
  //           // tnxRef: '8a3d5006-301c-4696-9ba5-af0b62b778b6',
  //         } : {}),
  //         userId: users[userId].id,
  //         tripId: trip.id,
  //       }
  //     })
  //     i += 1
  //   }
  // }



};
const removeSeedDataExceptAdmin = async () => {
  console.log('remove trips');
  await prisma.trip.deleteMany();
  console.log('remove banks');
  await prisma.bank.deleteMany();
  console.log('remove communities');
  await prisma.community.deleteMany();
  console.log('remove users');
  await prisma.user.deleteMany({
    where: {
      isAdmin: false,
    },
  });
  console.log('remove category');
  await prisma.category.deleteMany();
};
// main()
//   .catch((e) => console.log(e))
//   .then(() => console.log('done'));
module.exports = { main }