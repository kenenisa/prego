/*
  Warnings:

  - A unique constraint covering the columns `[name]` on the table `TripActivites` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[name]` on the table `TripPackageIncluded` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "TripActivites_name_key" ON "TripActivites"("name");

-- CreateIndex
CREATE UNIQUE INDEX "TripPackageIncluded_name_key" ON "TripPackageIncluded"("name");
