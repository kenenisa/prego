/*
  Warnings:

  - The primary key for the `TripsOnTripActivities` table will be changed. If it partially fails, the table could be left without primary key constraint.
  - You are about to drop the column `tripActivitesId` on the `TripsOnTripActivities` table. All the data in the column will be lost.
  - You are about to drop the `TripActivites` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `tripActivitiesId` to the `TripsOnTripActivities` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "TripsOnTripActivities" DROP CONSTRAINT "TripsOnTripActivities_tripActivitesId_fkey";

-- AlterTable
ALTER TABLE "TripsOnTripActivities" DROP CONSTRAINT "TripsOnTripActivities_pkey",
DROP COLUMN "tripActivitesId",
ADD COLUMN     "tripActivitiesId" TEXT NOT NULL,
ADD CONSTRAINT "TripsOnTripActivities_pkey" PRIMARY KEY ("tripId", "tripActivitiesId");

-- DropTable
DROP TABLE "TripActivites";

-- CreateTable
CREATE TABLE "TripActivities" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,

    CONSTRAINT "TripActivities_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "TripActivities_name_key" ON "TripActivities"("name");

-- AddForeignKey
ALTER TABLE "TripsOnTripActivities" ADD CONSTRAINT "TripsOnTripActivities_tripActivitiesId_fkey" FOREIGN KEY ("tripActivitiesId") REFERENCES "TripActivities"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
