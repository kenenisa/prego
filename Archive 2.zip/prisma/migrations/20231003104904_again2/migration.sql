/*
  Warnings:

  - You are about to drop the column `communityName` on the `communities` table. All the data in the column will be lost.
  - You are about to drop the column `isPublished` on the `trips` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[name]` on the table `communities` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX "communities_communityName_key";

-- AlterTable
ALTER TABLE "communities" DROP COLUMN "communityName",
ADD COLUMN     "name" TEXT;

-- AlterTable
ALTER TABLE "trips" DROP COLUMN "isPublished";

-- CreateIndex
CREATE UNIQUE INDEX "communities_name_key" ON "communities"("name");
