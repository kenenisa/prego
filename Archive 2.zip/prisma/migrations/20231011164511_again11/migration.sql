/*
  Warnings:

  - A unique constraint covering the columns `[tripId,userId]` on the table `tnxs` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "tnxs_tripId_userId_key" ON "tnxs"("tripId", "userId");
