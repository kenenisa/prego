/*
  Warnings:

  - You are about to drop the column `activities` on the `trips` table. All the data in the column will be lost.
  - You are about to drop the column `packageIncludes` on the `trips` table. All the data in the column will be lost.
  - Added the required column `isChildFriendly` to the `trips` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "trips" DROP COLUMN "activities",
DROP COLUMN "packageIncludes",
ADD COLUMN     "isChildFriendly" BOOLEAN NOT NULL;

-- CreateTable
CREATE TABLE "TripPackageIncluded" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,

    CONSTRAINT "TripPackageIncluded_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TripsOnTripPackageIncluded" (
    "tripId" TEXT NOT NULL,
    "tripPackageIncludedId" TEXT NOT NULL,
    "assignedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "TripsOnTripPackageIncluded_pkey" PRIMARY KEY ("tripId","tripPackageIncludedId")
);

-- CreateTable
CREATE TABLE "TripActivites" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,

    CONSTRAINT "TripActivites_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TripsOnTripActivities" (
    "tripId" TEXT NOT NULL,
    "tripActivitesId" TEXT NOT NULL,
    "assignedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "TripsOnTripActivities_pkey" PRIMARY KEY ("tripId","tripActivitesId")
);

-- AddForeignKey
ALTER TABLE "TripsOnTripPackageIncluded" ADD CONSTRAINT "TripsOnTripPackageIncluded_tripId_fkey" FOREIGN KEY ("tripId") REFERENCES "trips"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TripsOnTripPackageIncluded" ADD CONSTRAINT "TripsOnTripPackageIncluded_tripPackageIncludedId_fkey" FOREIGN KEY ("tripPackageIncludedId") REFERENCES "TripPackageIncluded"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TripsOnTripActivities" ADD CONSTRAINT "TripsOnTripActivities_tripId_fkey" FOREIGN KEY ("tripId") REFERENCES "trips"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TripsOnTripActivities" ADD CONSTRAINT "TripsOnTripActivities_tripActivitesId_fkey" FOREIGN KEY ("tripActivitesId") REFERENCES "TripActivites"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
