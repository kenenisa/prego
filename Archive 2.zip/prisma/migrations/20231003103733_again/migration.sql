/*
  Warnings:

  - You are about to drop the column `bio` on the `communities` table. All the data in the column will be lost.
  - You are about to drop the column `communityUsername` on the `communities` table. All the data in the column will be lost.
  - You are about to drop the column `contactNumber` on the `communities` table. All the data in the column will be lost.
  - You are about to drop the column `creatorId` on the `communities` table. All the data in the column will be lost.
  - You are about to drop the column `name` on the `communities` table. All the data in the column will be lost.
  - You are about to drop the column `subaccountId` on the `communities` table. All the data in the column will be lost.
  - You are about to drop the column `organizerId` on the `trips` table. All the data in the column will be lost.
  - You are about to drop the column `organizerUserId` on the `trips` table. All the data in the column will be lost.
  - You are about to drop the column `banner` on the `users` table. All the data in the column will be lost.
  - You are about to drop the column `bio` on the `users` table. All the data in the column will be lost.
  - You are about to drop the column `email` on the `users` table. All the data in the column will be lost.
  - You are about to drop the column `firstName` on the `users` table. All the data in the column will be lost.
  - You are about to drop the column `lastName` on the `users` table. All the data in the column will be lost.
  - You are about to drop the column `password` on the `users` table. All the data in the column will be lost.
  - You are about to drop the column `username` on the `users` table. All the data in the column will be lost.
  - You are about to drop the `_followers` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `_manager` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `_sharedUser` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `banks` table. If the table is not empty, all the data it contains will be lost.
  - A unique constraint covering the columns `[communityName]` on the table `communities` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `accountNumber` to the `communities` table without a default value. This is not possible if the table is not empty.
  - Added the required column `bankCode` to the `communities` table without a default value. This is not possible if the table is not empty.
  - Added the required column `organizerId` to the `communities` table without a default value. This is not possible if the table is not empty.
  - Added the required column `subAccountId` to the `communities` table without a default value. This is not possible if the table is not empty.
  - Added the required column `communityId` to the `trips` table without a default value. This is not possible if the table is not empty.
  - Added the required column `fullName` to the `users` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "_followers" DROP CONSTRAINT "_followers_A_fkey";

-- DropForeignKey
ALTER TABLE "_followers" DROP CONSTRAINT "_followers_B_fkey";

-- DropForeignKey
ALTER TABLE "_manager" DROP CONSTRAINT "_manager_A_fkey";

-- DropForeignKey
ALTER TABLE "_manager" DROP CONSTRAINT "_manager_B_fkey";

-- DropForeignKey
ALTER TABLE "_sharedUser" DROP CONSTRAINT "_sharedUser_A_fkey";

-- DropForeignKey
ALTER TABLE "_sharedUser" DROP CONSTRAINT "_sharedUser_B_fkey";

-- DropForeignKey
ALTER TABLE "banks" DROP CONSTRAINT "banks_communityId_fkey";

-- DropForeignKey
ALTER TABLE "communities" DROP CONSTRAINT "communities_creatorId_fkey";

-- DropForeignKey
ALTER TABLE "trips" DROP CONSTRAINT "trips_organizerId_fkey";

-- DropForeignKey
ALTER TABLE "trips" DROP CONSTRAINT "trips_organizerUserId_fkey";

-- DropIndex
DROP INDEX "communities_communityUsername_key";

-- DropIndex
DROP INDEX "users_email_key";

-- DropIndex
DROP INDEX "users_username_key";

-- AlterTable
ALTER TABLE "communities" DROP COLUMN "bio",
DROP COLUMN "communityUsername",
DROP COLUMN "contactNumber",
DROP COLUMN "creatorId",
DROP COLUMN "name",
DROP COLUMN "subaccountId",
ADD COLUMN     "accountNumber" TEXT NOT NULL,
ADD COLUMN     "bankCode" TEXT NOT NULL,
ADD COLUMN     "communityName" TEXT,
ADD COLUMN     "organizerId" TEXT NOT NULL,
ADD COLUMN     "subAccountId" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "trips" DROP COLUMN "organizerId",
DROP COLUMN "organizerUserId",
ADD COLUMN     "communityId" TEXT NOT NULL,
ADD COLUMN     "isPublished" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "users" DROP COLUMN "banner",
DROP COLUMN "bio",
DROP COLUMN "email",
DROP COLUMN "firstName",
DROP COLUMN "lastName",
DROP COLUMN "password",
DROP COLUMN "username",
ADD COLUMN     "age" INTEGER,
ADD COLUMN     "fullName" TEXT NOT NULL,
ADD COLUMN     "gender" TEXT,
ADD COLUMN     "isOrganizer" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "otp" TEXT;

-- DropTable
DROP TABLE "_followers";

-- DropTable
DROP TABLE "_manager";

-- DropTable
DROP TABLE "_sharedUser";

-- DropTable
DROP TABLE "banks";

-- CreateIndex
CREATE UNIQUE INDEX "communities_communityName_key" ON "communities"("communityName");

-- AddForeignKey
ALTER TABLE "communities" ADD CONSTRAINT "communities_organizerId_fkey" FOREIGN KEY ("organizerId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "trips" ADD CONSTRAINT "trips_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES "communities"("id") ON DELETE CASCADE ON UPDATE CASCADE;
