/*
  Warnings:

  - You are about to drop the column `firstName` on the `tnxs` table. All the data in the column will be lost.
  - You are about to drop the column `phoneNumber` on the `tnxs` table. All the data in the column will be lost.
  - Added the required column `userId` to the `tnxs` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "tnxs" DROP COLUMN "firstName",
DROP COLUMN "phoneNumber",
ADD COLUMN     "amountOfPeople" INTEGER NOT NULL DEFAULT 1,
ADD COLUMN     "userId" TEXT NOT NULL,
ALTER COLUMN "tnxRef" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "tnxs" ADD CONSTRAINT "tnxs_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
