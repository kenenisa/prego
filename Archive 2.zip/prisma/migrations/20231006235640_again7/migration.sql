-- AlterTable
ALTER TABLE "users" ADD COLUMN     "emergencyNumber" TEXT;
