/*
  Warnings:

  - You are about to drop the column `destination` on the `trips` table. All the data in the column will be lost.
  - Added the required column `destinationId` to the `trips` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "tnxs" ADD COLUMN     "isRefunded" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "trips" DROP COLUMN "destination",
ADD COLUMN     "destinationId" TEXT NOT NULL;

-- CreateTable
CREATE TABLE "Destination" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,

    CONSTRAINT "Destination_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Destination_name_key" ON "Destination"("name");

-- AddForeignKey
ALTER TABLE "trips" ADD CONSTRAINT "trips_destinationId_fkey" FOREIGN KEY ("destinationId") REFERENCES "Destination"("id") ON DELETE CASCADE ON UPDATE CASCADE;
