-- DropForeignKey
ALTER TABLE "TripsOnTripActivities" DROP CONSTRAINT "TripsOnTripActivities_tripActivitiesId_fkey";

-- DropForeignKey
ALTER TABLE "TripsOnTripActivities" DROP CONSTRAINT "TripsOnTripActivities_tripId_fkey";

-- DropForeignKey
ALTER TABLE "TripsOnTripPackageIncluded" DROP CONSTRAINT "TripsOnTripPackageIncluded_tripId_fkey";

-- DropForeignKey
ALTER TABLE "TripsOnTripPackageIncluded" DROP CONSTRAINT "TripsOnTripPackageIncluded_tripPackageIncludedId_fkey";

-- AddForeignKey
ALTER TABLE "TripsOnTripPackageIncluded" ADD CONSTRAINT "TripsOnTripPackageIncluded_tripId_fkey" FOREIGN KEY ("tripId") REFERENCES "trips"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TripsOnTripPackageIncluded" ADD CONSTRAINT "TripsOnTripPackageIncluded_tripPackageIncludedId_fkey" FOREIGN KEY ("tripPackageIncludedId") REFERENCES "TripPackageIncluded"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TripsOnTripActivities" ADD CONSTRAINT "TripsOnTripActivities_tripId_fkey" FOREIGN KEY ("tripId") REFERENCES "trips"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TripsOnTripActivities" ADD CONSTRAINT "TripsOnTripActivities_tripActivitiesId_fkey" FOREIGN KEY ("tripActivitiesId") REFERENCES "TripActivities"("id") ON DELETE CASCADE ON UPDATE CASCADE;
