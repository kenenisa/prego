-- AlterTable
ALTER TABLE "tnxs" ADD COLUMN     "amount" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "initiatedPayment" BOOLEAN NOT NULL DEFAULT false;
