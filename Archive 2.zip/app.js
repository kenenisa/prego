const express = require('express');
require('dotenv').config();
const app = express();
const cors = require('cors');
const { makeEnvExample } = require('./utils');
const path = require('path')
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(express.static('public'));

const allRoutes = require('./routes');
/**all routes are declared here */
app.use('/api', allRoutes);

/**error handling middleware(all errors go through here, when the router handlers call next with an error) */
app.use((err, res, next) => {
  // console.log(err);
  if (err.message) {

    let myError = JSON.parse(err.message);
    const status = myError.status;
    delete myError.status;
    return res.status(status).send({ error: myError });
  }
  // console.log(err, _req, res)
  // res.status(404).send({ route: 'NOT FOUND' })
  try {
    next()
  } catch (e) {
    console.log(e)
  }
  // res.sendFile(path.resolve(__dirname, 'public', 'index.html'));
});

/**handle not found request */
app.use('/api/*', (_req, res) => {
  res.status(404).send({ error: 'Endpoint not found' });
});
//admin pages
app.use('/admin/*', (_req, res) => {
  res.sendFile(path.resolve(__dirname, 'public', 'admin', 'index.html'));
});
app.use('*', (_req, res) => {
  res.sendFile(path.resolve(__dirname, 'public', 'index.html'));
  // res.status(404).send({ error: 'Endpoint not found' });
});

const port = process.env.PORT || 4000;
//create .env.example
if (process.env.NODE_ENV === 'development') {
  makeEnvExample();
}
module.exports = app.listen(port, () => {
  console.log(`App listening on port ${port}!`);
});
